!----------------------------------------------
!        Exemples de programme Fortran
!         ecrit dans le format libre
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------
PROGRAM FortranFormatLibre	

PRINT*,"Programme ecrit au format LIBRE"
PRINT*,"Et voila... Cela se ressemble, non ?"
PRINT*,"Neanmoins, ce format permet bien plus de choses que le format fixe..."

END PROGRAM FortranFormatLibre
