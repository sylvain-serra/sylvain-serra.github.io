*----------------------------------------------
*        Exemples de programme Fortran
*         ecrit dans le format libre
*
* Auteur : S. Serra
* Mail   : sylvain.serra@univ-pau.fr
* Date   : 19 Aout 2013
*----------------------------------------------
       PROGRAM FortranFormatFixe	
       
       PRINT*,"Programme ecrit au format FIXE"
       PRINT*,"Et voila..."

       END PROGRAM FortranFormatFixe
