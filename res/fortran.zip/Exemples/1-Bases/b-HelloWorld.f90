PROGRAM Contact

PRINT*,'Hello World'

END PROGRAM Contact

