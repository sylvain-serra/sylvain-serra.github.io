!=========================================================================================
!				Programme mettant en oeuvre une surcharge d'operateurs
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementsSurcharge1
USE TypePoint
USE DefinitionOperateurs
IMPLICIT NONE
Type(Point) :: A,B,C

A = Point(-1.D0,-1.D0,-1.D0)

B%x = 1.D0
B%y = B%x
B%z = B%x

C = A+B

! Affichage
PRINT*,'Point A = ',A%x,',',A%y,',',A%z
PRINT*,'Point B = ',B%x,',',B%y,',',B%z
PRINT*,'Point C = ',C%x,',',C%y,',',C%z

END PROGRAM SupplementsSurcharge1
