!=========================================================================================
!				Programme définissant une fonction récursive
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementFonctions
IMPLICIT NONE

! Déclaration des variables
INTEGER :: n, final, fibonnaci

	 
!------------------------------------------
!           Coeur du programme
!------------------------------------------

PRINT*,"Quelle est la valeur de n ?"
READ(*,*) n
  
final = fibonnaci(n)
PRINT*,"La valeur finale de la suite de Fibonaci pour n = ",n," est : ",final

STOP

END PROGRAM SupplementFonctions


!------------------------------------------
!           Procedures recursives
!------------------------------------------


RECURSIVE FUNCTION fibonnaci(n) RESULT (valeurFinale)
  IMPLICIT NONE
  INTEGER, INTENT(IN) :: n
  INTEGER :: valeurFinale
  
  IF (n <= 2) THEN
    valeurFinale = 1
  ELSE
    valeurFinale = fibonnaci(n-1) + fibonnaci(n-2)
  ENDIF
  
END FUNCTION fibonnaci

