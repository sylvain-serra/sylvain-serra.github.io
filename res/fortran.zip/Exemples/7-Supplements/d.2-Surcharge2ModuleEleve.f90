!=========================================================================================
!				Module definissant un nouveau type de variable
!                  Eleve : un nom (chaine de caractères
!                          une annee de promotion (entier)
!                          une note (réelle)
!                          
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

MODULE TypeEleve
IMPLICIT NONE
TYPE ELEVE
  CHARACTER(LEN=30) :: nom
  INTEGER :: promotion
  DOUBLE PRECISION :: moyenne
END TYPE ELEVE
END MODULE TypeEleve
