!=========================================================================================
!				Programme définissant une procédure dont l'un des
!                 arguments peut être omis (argument optionnel)
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementFonctions2
IMPLICIT NONE

REAL :: x,y

!------------------------------------------
!           Coeur du programme
!------------------------------------------

x = 1.E0
y = 5.E0

PRINT*,'Appel classique de procédure AVEC TOUS les arguments'
CALL TestOption(x,y)

PRINT*,''

PRINT*,'Appel classique de procédure SANS UN argument'
CALL TestOption(x)

STOP


!------------------------------------------
!                 Procedures
!------------------------------------------
CONTAINS

SUBROUTINE TestOption(a,b)
IMPLICIT NONE
REAL, INTENT(IN) :: a
REAL, INTENT(IN), OPTIONAL :: b
IF(PRESENT(b)) THEN
  PRINT*,a+b
ELSE
  PRINT*,a
ENDIF
END SUBROUTINE TestOption


END PROGRAM SupplementFonctions2


