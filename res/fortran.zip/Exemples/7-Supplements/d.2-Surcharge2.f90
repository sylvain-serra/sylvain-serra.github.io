!=========================================================================================
!				Programme mettant en oeuvre une surchage d'operateurs
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementsSurcharge2
USE TypeEleve
USE DefinitionOperateurs
IMPLICIT NONE
Type(ELEVE) :: A,B,C

! Premier eleve
!===========================
A%nom = "Anonymous"
A%promotion = 2013
A%moyenne = 14.7D0

! Affichage
PRINT*,"Premier eleve :"
PRINT*,"   Nom : ",A%nom
PRINT*,"   Promotion : ",A%promotion
PRINT*,"   Moyenne : ",A%moyenne

! Second eleve
!===========================
B%nom = "Doppelganger"
B = A

! Affichage
PRINT*,"Second eleve :"
PRINT*,"   Nom : ",B%nom
PRINT*,"   Promotion : ",B%promotion
PRINT*,"   Moyenne : ",B%moyenne

! Troisieme eleve
!===========================
C%nom = "Calimero"
C = ALEA(B)

! Affichage
PRINT*,"Dernier eleve :"
PRINT*,"   Nom : ",C%nom
PRINT*,"   Promotion : ",C%promotion
PRINT*,"   Moyenne : ",C%moyenne



END PROGRAM SupplementsSurcharge2
