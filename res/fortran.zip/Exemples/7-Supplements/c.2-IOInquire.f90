!=========================================================================================
!				Programme testant l'existence éventuelle d'un fichier
!                      et agissant selon le type de réponse
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM InterrogationFichier
IMPLICIT NONE
LOGICAL existence, reponse
INTEGER ios,numero
CHARACTER(LEN=10) :: option
CHARACTER(LEN=30) :: nom

! Test sur l'existence d'un fichier
INQUIRE( FILE="fichierEcrase.txt", EXIST=existence )

IF ( existence ) THEN
  PRINT*,'Le fichier fichierEcrase.txt existe'
ELSE
  PRINT*,'Le fichier fichierEcrase.txt n''existe pas'
ENDIF

! Ouverture du fichier s'il existe
IF ( existence ) THEN
  OPEN(UNIT=99, FILE='fichierEcrase.txt', STATUS='OLD', ACTION='READ',IOSTAT=ios)
  IF(0 == ios) THEN
    PRINT*,'Ouverture de fichierEcrase.txt : OK'
  ELSE
    PRINT*,'Probleme ouverture de fichierEcrase.txt : ',ios
  ENDIF
ENDIF

! Interrogation du fichier
PRINT*,'=== INTERROGATION DU FICHIER ==='

INQUIRE( FILE="fichierEcrase.txt", NUMBER=numero, ACCESS=option)
PRINT*,'Numero unite logique : ',numero
PRINT*,'Type acces : ',option

INQUIRE( UNIT=99, NAME=nom)
PRINT*,'Nom du fichier : ',ADJUSTL(nom)

! Fermeture du fichier
CLOSE(99)

STOP
END PROGRAM InterrogationFichier




