!=========================================================================================
!				Programme testant des fonctions intrinseques utiles
!                 pour la manipuluation efficiente de tableaux
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementTableaux
IMPLICIT NONE
INTEGER :: i,j
DOUBLE PRECISION, DIMENSION(3,3) :: Matrice

! 1) Remplissage de la matrice
FORALL (i=1:3, j=1:3)
  Matrice(i,j) = i*j
END FORALL 
PRINT*,'Matrice = '
PRINT*,(Matrice(i,:),i=1,3)

! 2) Utilisation des nouvelles fonctions intrinseques
IF (ALL(Matrice >= 0.E0)) THEN 
  PRINT*, "Tous les elements de Matrice sont positifs."
ENDIF

IF (ANY(Matrice >= 0.E0)) THEN 
  PRINT*, "Il existe un element de Matrice au moins qui est positif."
ENDIF

PRINT*,"Nombre d'elements positifs de Matrice       : ", COUNT(matrice >= 0.E0)
PRINT*,"Nombre d'elements superieurs a 6 de Matrice : ", COUNT(matrice >= 6.E0)

STOP
END PROGRAM SupplementTableaux
