!=========================================================================================
!				Programme utilisant une namelist pour la lecture et l'écriture
!                                   depuis un fichier
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementIO2
IMPLICIT NONE
INTEGER, PARAMETER :: FICH = 10
INTEGER :: err
INTEGER :: i
DOUBLE PRECISION :: x
! Declaration d'une liste (NAMELIST)
NAMELIST/Liste1/i,x

i = 1
x = 0.1D0

PRINT*,'Affichage de la liste'
WRITE(*, NML=Liste1)

PRINT*,'Lecture de la liste au clavier'
READ(*, NML=Liste1)
WRITE(*, NML=Liste1)

PRINT*,'Lecture de la liste dans un fichier'
OPEN(UNIT=FICH,FILE='fichiernamelist.txt',STATUS='OLD',ACTION='READ',IOSTAT=err)
IF(err /= 0) THEN
  PRINT*,'PROBLEME ouverture fichier fichiernamelist.txt : erreur = ',err
ENDIF
PRINT*,'Essai 1 :'
READ(FICH, NML=Liste1)
WRITE(*, NML=Liste1)
PRINT*,'Essai 2 :'
READ(FICH, NML=Liste1)
WRITE(*, NML=Liste1)
CLOSE(FICH)

STOP
END PROGRAM SupplementIO2
