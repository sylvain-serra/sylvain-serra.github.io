!=========================================================================================
!				Module definissant la surchage d'operateurs pour 
!                l'utilisation avec des variables de type ELEVE
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

MODULE DefinitionOperateurs
IMPLICIT NONE

! Surcharge opérateur d'affectation
INTERFACE ASSIGNMENT (=)
  MODULE PROCEDURE egal
END INTERFACE

! Création d'un nouvel opérateur (que l'on nommera ALEA...)
INTERFACE OPERATOR (.ALEA.)
  MODULE PROCEDURE ALEA
END INTERFACE



CONTAINS


  ! fonction faisant la surcharge operateur =
  SUBROUTINE egal(toto,titi)
  USE TypeEleve
  IMPLICIT NONE
  TYPE(ELEVE), INTENT(OUT) :: toto
  TYPE(ELEVE), INTENT(IN) :: titi
 
  toto%promotion = titi%promotion
  toto%moyenne = titi%moyenne
  
  END SUBROUTINE egal
  
  
  ! fonction définissant l'opération effectuée par le nouvel operateur .ALEA.
  FUNCTION ALEA(toto)
  USE TypeEleve
  IMPLICIT NONE
  TYPE(ELEVE), INTENT(IN) :: toto
  TYPE(ELEVE) :: ALEA
  
  ALEA%promotion = toto%promotion
  ALEA%moyenne = 0.5D0*toto%moyenne
  
  END FUNCTION ALEA


END MODULE DefinitionOperateurs
