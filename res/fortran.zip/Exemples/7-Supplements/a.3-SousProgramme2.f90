!----------------------------------------------
!         Exemple de programme utilisant 
!            des procédures internes
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2018
!----------------------------------------------

PROGRAM ProcedureSubroutine
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION :: x,y

! Coeur du programme
!------------------------------------------------------------------------------------------

x = 1.D0
y = 2.D0

PRINT*,"Dans le programme principal, x vaut:",x

CALL procInt()

PRINT*,"Dans le programme principal, x vaut:",x

CALL procExt(y)

PRINT*,"Dans le programme principal, x vaut:",x

CALL procExtChge(x)

PRINT*,"Dans le programme principal, x vaut:",x


STOP


! Procédures internes
!------------------------------------------------------------------------------------------

CONTAINS

SUBROUTINE procInt()
IMPLICIT NONE
! 1) Déclaration des variables
DOUBLE PRECISION :: x					! masquage de la variable globale du même nom

x = 10.D0 * y

PRINT*,"Dans le sous-programme interne, x vaut:",x

END SUBROUTINE procInt


END PROGRAM ProcedureSubroutine






! Procédures externes
!------------------------------------------------------------------------------------------

SUBROUTINE procExt(x)
IMPLICIT NONE
! 1) Arguments
DOUBLE PRECISION, INTENT(IN) :: x

! 2) Coeur de la subroutine
PRINT*,"Dans le sous-programme externe, l'argument x vaut:",x

END	SUBROUTINE	procExt


SUBROUTINE procExtChge(a)
IMPLICIT NONE
! 1) Arguments
DOUBLE PRECISION, INTENT(INOUT) :: a

! 2) Coeur de la subroutine
a = 2.D0 * a

END	SUBROUTINE	procExtChge
