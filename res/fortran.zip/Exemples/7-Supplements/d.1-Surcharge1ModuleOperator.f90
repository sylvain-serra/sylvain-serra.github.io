!=========================================================================================
!				   Module pour la surcharge d'operateurs
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

MODULE DefinitionOperateurs
IMPLICIT NONE

! Surcharge Operateur +
INTERFACE OPERATOR (+)
  MODULE PROCEDURE somme
END INTERFACE

CONTAINS

  ! Définition de la fonction utilisée pour la surcharge de l'opérateur +
  FUNCTION somme(P1,P2)
  USE TypePoint
  IMPLICIT NONE
  TYPE(Point), INTENT(IN) :: P1,P2
  TYPE(Point) :: somme
  
  somme%x = P1%x + P2%x
  somme%y = P1%y + P2%y
  somme%z = P1%z + P2%z
  
  END FUNCTION somme

END MODULE DefinitionOperateurs
