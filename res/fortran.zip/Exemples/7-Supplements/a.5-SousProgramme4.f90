!=========================================================================================
!				Programme utilisant une procédure qui dispose d'une 
!                   variable dont la valeur est conservée
!                      entre deux appels successifs
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!=========================================================================================

PROGRAM SupplementFonctions3
IMPLICIT NONE

	 
!------------------------------------------
!           Coeur du programme
!------------------------------------------


PRINT*,"Premier appel..."
WRITE(*,"(A26)",ADVANCE="NO")"     la variable vaut : "
CALL sauvegarde()

PRINT*
PRINT*,"Appel suivant..."
WRITE(*,"(A26)",ADVANCE="NO")"     la variable vaut : "
CALL sauvegarde()

PRINT*
PRINT*,"Appel suivant..."
WRITE(*,"(A26)",ADVANCE="NO")"     la variable vaut : "
CALL sauvegarde()

PRINT*
PRINT*,"Appel suivant..."
WRITE(*,"(A26)",ADVANCE="NO")"     la variable vaut : "
CALL sauvegarde()


STOP

END PROGRAM SupplementFonctions3



!------------------------------------------
!           Procedure avec une variable
!            dont la valeur se conserve
!------------------------------------------

SUBROUTINE sauvegarde()
IMPLICIT NONE
INTEGER, SAVE :: compteur

PRINT*,compteur

compteur = compteur + 1

END SUBROUTINE
