!=========================================================================================
!				Module pour la définition d'un nouveau type
!                       Point : 3 champs réels
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

MODULE TypePoint
IMPLICIT NONE
TYPE Point
  DOUBLE PRECISION :: x,y,z
END TYPE Point
END MODULE TypePoint
