!=========================================================================================
!				Programme montrant comment lire plusieurs fois un fichier
!                  i.e., comment revenir en arrière dans une lecture
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!=========================================================================================

PROGRAM SupplementIO
IMPLICIT NONE

INTEGER, PARAMETER :: FICH = 10
INTEGER :: err,i,j
DOUBLE PRECISION :: x
DOUBLE PRECISION, DIMENSION(6,2) :: Mat

! Initialisation
x = -1.D0
Mat(:,:) = 0.D0

! Exemple de lecture avec retour en arrière d'une ligne
!===================================================================
! Ouverture du fichier de valeur
OPEN(UNIT=FICH,FILE='fichierformat.txt',STATUS='OLD',ACTION='READ',IOSTAT=err)
IF(err /= 0) THEN
  PRINT*,'PROBLEME ouverture fichier fichierformat.txt : erreur = ',err
ENDIF

PRINT*,"x = ",x

! Premiere lecture
READ(FICH,*)x
PRINT*,"x = ",x

! Retour arriere d'une ligne
BACKSPACE(FICH)

! seconde lecture
READ(FICH,*)x
PRINT*,"x = ",x

! Fermeture du fichier
CLOSE(FICH)


PRINT*,""



! Exemple de lecture avec retour en arrière au début du fichier
!===================================================================
! Ouverture du fichier de valeur
OPEN(UNIT=FICH,FILE='fichierformat.txt',STATUS='OLD',ACTION='READ',IOSTAT=err)
IF(err /= 0) THEN
  PRINT*,'PROBLEME ouverture fichier fichierformat.txt : erreur = ',err
ENDIF

! Premiere lecture
DO i=1,3
  READ(FICH,*)Mat(i,1),Mat(i,2)
ENDDO
DO i=1,6
  PRINT*,(Mat(i,j),j=1,2)
ENDDO

! Seconde lecture
REWIND(FICH)

DO i=4,6
  READ(FICH,*)Mat(i,1),Mat(i,2)
ENDDO
PRINT*,'=================================='
DO i=1,6
  PRINT*,(Mat(i,j),j=1,2)
ENDDO

! Fermeture du fichier
CLOSE(FICH)

STOP
END PROGRAM SupplementIO
