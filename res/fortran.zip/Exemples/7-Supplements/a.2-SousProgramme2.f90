!----------------------------------------------
!         Exemple de programme utilisant 
!            des procédures internes
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2018
!----------------------------------------------

PROGRAM ProcedureSubroutine
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION :: x,y,z

! Coeur du programme
!------------------------------------------------------------------------------------------

x = 1.D0
y = 2.D0
z = 3.D0

PRINT*,"x = ",x
PRINT*,"y = ",y
PRINT*,"z = ",z

PRINT*,""
PRINT*,"Appel procedure interne"
CALL procInt()
PRINT*,"Retour appel procedure interne"

PRINT*,""
PRINT*,"Appel procedure externe"
CALL procExt(z,y,x)
PRINT*,"Retour appel procedure externe"

PRINT*,""
PRINT*,"x = ",x
PRINT*,"y = ",y
PRINT*,"z = ",z


STOP


! Procédures internes
!------------------------------------------------------------------------------------------

CONTAINS

SUBROUTINE procInt()
IMPLICIT NONE

PRINT*,"x = ",x							! Il s'agit ici des variables globales
PRINT*,"y = ",y
PRINT*,"z = ",z

END SUBROUTINE procInt


END PROGRAM ProcedureSubroutine


! Procédures externes
!------------------------------------------------------------------------------------------

SUBROUTINE procExt(x,y,z)
IMPLICIT NONE
! 1) Arguments
DOUBLE PRECISION, INTENT(IN) :: x
DOUBLE PRECISION, INTENT(IN) :: y
DOUBLE PRECISION, INTENT(IN) :: z

! 2) Coeur de la subroutine
PRINT*,"x = ",x							! Il s'agit ici des arguments
PRINT*,"y = ",y
PRINT*,"z = ",z

END	SUBROUTINE	procExt
