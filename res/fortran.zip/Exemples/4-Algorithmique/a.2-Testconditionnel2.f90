!----------------------------------------------------
!       Programme de demonstration sur les
!          tests conditionnels (CASE)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 17 Aout 2018
!----------------------------------------------------

PROGRAM TestConditionnel2
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: choix


! Programme principal
!=================================

PRINT*,"Tapez un chiffre sans me le dire..."
READ(*,*)choix

PRINT*,"   Premier essai pour que je devine..."
SELECT CASE(choix)
  CASE(0)
    PRINT*,"Eureka"
    PRINT*,"Votre choix etait 0"
  CASE(1)
    PRINT*,"Eureka"
    PRINT*,"Votre choix etait 1"
END SELECT

PRINT*,"   Dernier essai pour que je devine..."
SELECT CASE(choix)
  CASE(0)
    PRINT*,"Eureka"
    PRINT*,"Votre choix était 0"
  CASE(1)
    PRINT*,"Eureka"
    PRINT*,"Votre choix etait 1"
  CASE DEFAULT
    PRINT*,"Je sais que ce n'etait ni 0 ni 1"
END SELECT


END PROGRAM TestConditionnel2
