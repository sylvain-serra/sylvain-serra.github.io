!----------------------------------------------------
!       Programme de demonstration sur les
!          tests conditionnels (CASE)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM TestConditionnel3
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: mois 


! Programme principal
!=================================

PRINT*,'Donner votre mois de naissance svp :'
READ(*,*)mois

PRINT*,'La saison correspondante est :'
SELECT CASE (mois) 
  CASE(1,2,3) 
    PRINT*,'Hiver' 
  CASE(4,5,6) 
    PRINT*,'Printemps'
  CASE(7:9) 
    PRINT*,'Ete'
  CASE(10:12) 
    PRINT*,'Automne'
  CASE DEFAULT 
    PRINT*,'Saison inexistante...    Etes-vous japonais ?'
END SELECT

END PROGRAM TestConditionnel3
