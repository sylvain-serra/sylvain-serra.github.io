!----------------------------------------------------
!       Programme de demonstration sur les
!          boucles itératives (DO)
!     avec conditions de sortie de la boucle            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Boucle3
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i,j


! Programme principal
!=================================

j = 1
DO i = 1,10
  j = -1*j
  IF (j < 0) THEN
    CYCLE
  ENDIF
  PRINT*,'i = ',i
ENDDO
	
PRINT*,''
DO i = 1,10
  PRINT*,'i = ',i
  IF (i > 7) EXIT
ENDDO

PRINT*,''
DO i = 1,10
  IF (i > 7) EXIT
  PRINT*,'i = ',i
ENDDO
	
PRINT*,''
DO i = 1,10
  IF (i > 7) stop
  PRINT*,'i = ',i
ENDDO
PRINT*,'phrase jamais affichee (normalement)'


END PROGRAM Boucle3




