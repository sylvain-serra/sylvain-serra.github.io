!----------------------------------------------------
!       Programme de demonstration sur les
!          boucles itératives (DO)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Boucle1
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i
INTEGER, DIMENSION(25) :: Tab


! Programme principal
!=================================

PRINT*,'Boucle simple'
DO i = 1,25
  Tab(i) = i
  PRINT*,'i : ',i,'   Tab = ',Tab(i)
ENDDO

PRINT*,''
PRINT*,'Boucle mal faite : rien ne va se produire'
DO i = 1,0
  Tab(i) = 0
  PRINT*,'i : ',i,'   Tab = ',Tab(i)
ENDDO

PRINT*,''
PRINT*,'Boucle inversee'
DO i = 25,1,-1
  Tab(i) = 25-i+1
  PRINT*,'i : ',i,'   Tab = ',Tab(i)
ENDDO

PRINT*,''
PRINT*,'Boucle implicite'
PRINT*,(Tab(i),i=1,25,4)

END PROGRAM Boucle1




