!----------------------------------------------------
!       Programme de demonstration sur les
!     tests conditionnels (IF... ELSE)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM TestConditionnel1
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION :: val


! Programme principal
!=================================

! Lecture d'une valeur au clavier, fournie par l'utilisateur
PRINT*,'Veuillez donner un chiffre svp :'
READ(*,*)val

! 1) Test simple sur la valeur fournie
PRINT*,'1) Etude preliminaire'
IF(val /= 0) THEN
  PRINT*,'La valeur est non nulle'
ENDIF

! 2) Test complet sur la valeur fournie
PRINT*,'2) Etude complete'
IF(val < 0) THEN
  PRINT*,'La valeur est negative'
ELSE IF(val > 0) THEN
  PRINT*,'La valeur est positive'
ELSE
  PRINT*,'La valeur est nulle'
ENDIF

END PROGRAM TestConditionnel1
