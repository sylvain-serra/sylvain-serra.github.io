!----------------------------------------------------
!       Programme de demonstration sur les
!         boucles itératives (DO WHILE)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Boucle2
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i


! Programme principal
!=================================

PRINT*,"Donner une valeur entiere svp ?"
READ(*,*)i

DO WHILE(i/=0)
  PRINT*,'Je veux une valeur nulle :'
  READ(*,*)i
ENDDO

PRINT*,""

i = 10
DO WHILE(i>0)
!  PRINT*,"i = ",i

ENDDO

END PROGRAM Boucle2




