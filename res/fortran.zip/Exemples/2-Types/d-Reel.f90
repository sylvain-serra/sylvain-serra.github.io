!----------------------------------------------------
!             Programme trivial sur 
!                leS typeS reelS 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Reel
IMPLICIT NONE

! Declaration des variables
!======================================
REAL :: reelSimple
DOUBLE PRECISION :: reelDouble

! Coeur du programme
!======================================


PRINT*,"Donner la valeur de l'entier simple precision :"
READ(*,*)reelSimple
PRINT*,"Donner la valeur de l'entier double precision :"
READ(*,*)reelDouble

PRINT*,'Affichage des deux variables reelles'
PRINT*,'  reelSimple = ',reelSimple
PRINT*,'  reelDouble = ',reelDouble

END PROGRAM Reel