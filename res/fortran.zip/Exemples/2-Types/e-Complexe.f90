!----------------------------------------------------
!             Programme trivial sur 
!              leS typeS complexeS 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Complexe
IMPLICIT NONE

! Declaration des variables
!======================================
COMPLEX :: complexSimple
DOUBLE COMPLEX :: complexDouble

! Coeur du programme
!======================================
complexSimple = (1.E0,1.E0)
complexDouble = (-1.D0,-1.D0)

PRINT*,"Affichage des deux variables complexes"
PRINT*,"  complexSimple = ",complexSimple
PRINT*,"  complexDouble = ",complexDouble

END PROGRAM Complexe
