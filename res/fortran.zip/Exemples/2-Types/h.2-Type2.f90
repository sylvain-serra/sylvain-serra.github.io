!----------------------------------------------------
!          Programme exposant la construction 
!            d'un nouveau type de variables 
!          avec des CHAMPS de TYPE DIFFERENTS
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!----------------------------------------------------

PROGRAM TypeGeneral
IMPLICIT NONE

! Declaration des variables
!=================================

! 1) Déclaration d'un nouveau type pour manipuler des produits
TYPE Product
  INTEGER :: numberAvailable
  DOUBLE PRECISION  :: price
  CHARACTER(LEN=10) :: currency
END TYPE

! 2) Déclaration de variables de ce nouveau type "Product"
Type(Product) :: tomate, orange, iPad



! Initialisation
!=================================

tomate%numberAvailable = 99
tomate%price = 0.5D0
tomate%currency = "euros"

orange = tomate
orange%price = 0.25D0

iPad = Product(5, 600, "dollars")

! Affichage
!=================================

! 1) Affichage de l'ensemble des champs de chaque variable
PRINT*,"Affichage complet"
PRINT*,"-------------------------------------------------"

PRINT*,tomate

PRINT*

PRINT*,orange

PRINT*

PRINT*,iPad

! 2) Affichage d'un champ au choix (en fonction du besoin)

PRINT*

PRINT*,"Affichage selectif"
PRINT*,"-------------------------------------------------"

PRINT*,"Nombre de tomates en stock : ",tomate%numberAvailable
PRINT*,"Prix d'une orange : ",orange%price
PRINT*,"Quelle monnaie dois-je utiliser pour acheter un iPad : ",iPad%currency
PRINT*,"Combien de tomates (environ) puis-je acheter au lieu d'un iPad : ",iPad%price/1.7D0/tomate%price


END PROGRAM TypeGeneral