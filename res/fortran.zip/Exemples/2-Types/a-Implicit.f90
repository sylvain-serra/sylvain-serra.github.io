!----------------------------------------------------
!             Exemple de programme utilisant
!              des variables implicites 
!
!                  *** ATTENTION ***
!                FORTEMENT DECONSEILLE
!                     (INTERDIT)
!                  *****************
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM toto

! Declaration des variables
!======================================
IMPLICIT INTEGER(i),REAL*8(a-h,l-z)

! Coeur du programme
!======================================
i = 2
a = 2
PRINT*,'i=',i,'          a=',a
PRINT*,"a + x = ",a+x
PRINT*,"variable 'x' JAMAIS definie"

END PROGRAM toto
