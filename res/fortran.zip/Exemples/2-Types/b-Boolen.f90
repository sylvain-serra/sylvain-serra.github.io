!----------------------------------------------------
!             Programme trivial sur 
!                le type booleen 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Boolen
IMPLICIT NONE

! Declaration des variables
!======================================
LOGICAL :: bool			! variable logique pour demonstration

! Coeur du programme
!======================================
bool = .TRUE.
PRINT*,"Valeur de bool : ",bool
bool = .FALSE.
PRINT*,"Valeur de bool : ",bool

END PROGRAM Boolen