!----------------------------------------------------
!         Programme montrant les diverses
!       facons pour initialiser des variables 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Initialisation
IMPLICIT NONE

! Declaration des variables
!=================================
INTEGER :: var,bc
DOUBLE PRECISION :: x,y,z
DOUBLE PRECISION :: a,b

! Exemples des diverses possibilites
!=================================
! 1) Initialisation avec l'instruction DATA
DATA var/83/,bc/13/
DATA x,y,z/1.D0, 2.D0, 3.D0/				

! 2) Initialisation avec l'opérateur d'affectation
a = 1.d1														

! 3) Initialisation avec la commande READ(*,*)
PRINT*,"Valeur de b svp :"
READ(*,*)b

! Affichage
!=================================
PRINT*,"var = ",var,"   bc = ",bc
PRINT*,"x = ",x,"   y = ",y,"   z = ",z
PRINT*,"a = ",a
PRINT*,"b = ",b

END PROGRAM Initialisation