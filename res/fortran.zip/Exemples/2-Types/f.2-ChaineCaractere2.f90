!----------------------------------------------------
!             Programme un peu plus complet 
!                  sur le type character 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!----------------------------------------------------

PROGRAM ChaineCaractere2
IMPLICIT NONE

! Declaration des variables
!======================================
CHARACTER(LEN=8) :: firstName 
CHARACTER(LEN=4) :: familyName 
CHARACTER(LEN=4) :: nickName
CHARACTER(LEN=2) :: aka
CHARACTER(LEN=7) :: aka2

! Coeur du programme
!======================================
firstName  = "Emmanuel"
familyName = 'Kant'
nickName   = firstName(3:6)
aka        = firstName(1:1) // familyName(1:1)
aka2       = firstName(1:1) // familyName(1:1) // familyName(4:4) // "2014"


PRINT*,"Patronyme officiel : ",familyName," ",firstName
PRINT*,"Mon petit surnom   : ",nickName
PRINT*,"Mes noms de code   : ",aka," et ",aka2


END PROGRAM ChaineCaractere2
