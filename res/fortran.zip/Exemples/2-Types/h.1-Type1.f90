!----------------------------------------------------
!          Programme exposant la construction 
!            d'un nouveau type de variables 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM TypePoint
IMPLICIT NONE

! Declaration des variables
!=================================
! 1) Déclaration d'une structure pour décrire un point
TYPE Point
  DOUBLE PRECISION :: x,y,z
END TYPE
! 2) Utilisation de ce nouveau type pour déclarer des variables de type Point
Type(Point) :: Origin,A,B,C

DOUBLE PRECISION :: x


! Initialisation
!=================================

! 1) Par saisie au clavier de l'utilisateur
PRINT*,"Coordonnees du point A requises"
PRINT*,"coord x : "
READ(*,*)A%x
PRINT*,"coord y : "
READ(*,*)A%y
PRINT*,"coord z : "
READ(*,*)A%z

! 2) Affectations directes du programmeur
!    a- affectations successives de chaque champ
B%x = 1.D0
B%y = B%x
B%z = B%x
!    b- affectation globale de tous les champs (par copie d'une autre structure)
C = A
!    c- affectation par utilisation du prototype de la structure
Origin = Point(0.D0,0.D0,0.D0)


! Affichage
!=================================
PRINT*,"Point O = ",Origin%x,",",Origin%y,",",Origin%z
PRINT*,"Point A = ",A%x,",",A%y,",",A%z
PRINT*,"Point B = ",B%x,",",B%y,",",B%z
PRINT*,"Point C = ",C%x,",",C%y,",",C%z
print*, A

END PROGRAM TypePoint
