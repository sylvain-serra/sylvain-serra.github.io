!----------------------------------------------------
!             Programme trivial sur 
!                le type entier 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM Entier
IMPLICIT NONE

! Declaration des variables
!======================================
INTEGER :: entierRelatif

! Coeur du programme
!======================================
entierRelatif = 123456789
PRINT*,"Valeur de entierRelatif = ",entierRelatif
PRINT*,"Entrer une nouvelle valeur :"
READ(*,*) entierRelatif
entierRelatif = 2*entierRelatif
PRINT*,"le double de entierRelatif = ",entierRelatif

END PROGRAM Entier
