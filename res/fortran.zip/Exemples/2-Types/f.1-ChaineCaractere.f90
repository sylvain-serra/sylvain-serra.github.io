!----------------------------------------------------
!             Programme trivial sur 
!               le type character 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM ChaineCaractere
IMPLICIT NONE

! Declaration des variables
!======================================
CHARACTER :: lettre				! variable pouvant contenir UN caractère
CHARACTER(LEN=6) :: mot			! variable pouvant contenir SIX caractères

! Coeur du programme
!======================================
lettre = 'a'
mot    = 'ensgti'

PRINT*,"La lettre est : ",lettre
PRINT*,"Le mot est    : ",mot

END PROGRAM ChaineCaractere
