!----------------------------------------------------
!          Exemples d'initialisation des
!             variables d'un tableau
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauInitialisation2
IMPLICIT NONE

! Déclaration des variables 
!=================================
INTEGER :: errAlloc
REAL, DIMENSION(5) :: Vec,Vec2
REAL, DIMENSION(-2:2) :: Vec3
REAL, DIMENSION(5,5) :: Mat
REAL, DIMENSION(-2:2,5:10) :: Mat2

! Déroulement du programme
!=================================

! 1) Affichage de début
PRINT*,'***********************************************************************************'
PRINT*,'                                DEBUT DU PROGRAMME'

Vec(1) = 1.E0
Vec(2) = 2.E0
Vec(3) = 3.E0
Vec(4) = 4.E0
Vec(5) = 5.E0
PRINT*,'Vec : ',Vec

Vec2 = -1.E0*Vec
PRINT*,'Vec2 : ',Vec2

Vec3 = Vec*Vec2
PRINT*,'Vec3 : ',Vec3
PRINT*,'   Vec3(-2) = ',Vec3(-2)

!PRINT*,Vec(500)

PRINT*,'========================================================'

Mat = 0.E0
Mat(1,:) = Vec2
PRINT*,'Mat : '
PRINT*,Mat(1,:)
PRINT*,Mat(2,:)
PRINT*,Mat(3,:)
PRINT*,Mat(4,:)
PRINT*,Mat(5,:)

Mat2 = 1.E0
PRINT*,'Mat2 : '
PRINT*,Mat2(-2,:)
PRINT*,Mat2(-1,:)
PRINT*,Mat2(0,:)
PRINT*,Mat2(1,:)
PRINT*,Mat2(2,:)

PRINT*,'   Comportement etrange :'
Mat2(50,:) = 0.E0
PRINT*,'Mat2(50,:) = ',Mat2(50,:)


PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'


END PROGRAM TableauInitialisation2
