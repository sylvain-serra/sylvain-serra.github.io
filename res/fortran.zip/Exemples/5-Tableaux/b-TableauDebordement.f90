!----------------------------------------------------
!          Programme de demonstration des erreurs
!            de débordement avec les tableaux
!                    (TRES) IMPORTANT       
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauDebordement
IMPLICIT NONE

! Déclaration
!=================================
REAL, DIMENSION(5) :: Vec
DOUBLE PRECISION, DIMENSION(2,2) :: Mat

! Coeur du programme
!=================================

! 1) Tableau à une dimension
Vec(1) = 1.E0
Vec(2) = 2.E0
Vec(3) = 3.E0
Vec(4) = 4.E0
Vec(5) = 5.E0
PRINT*,'Tableau Vec : ',Vec

Vec(6) = 6.E0
PRINT*,'Tableau Vec : ',Vec

! 1) Tableau à deux dimensions
Mat(1,1) = 1.D0
Mat(1,2) = 0.D0
Mat(2,1) = 0.D0
Mat(2,2) = 1.D0
PRINT*,'Tableau Mat : ',Mat

Mat(3,1) = 3.D0
PRINT*,'Tableau Mat : ',Mat


END PROGRAM TableauDebordement
