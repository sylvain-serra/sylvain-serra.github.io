!----------------------------------------------------
!          Programme de presentation
!           des tableaux dynamiques 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauDynamique1
IMPLICIT NONE

! Déclaration des variables 
!=================================
!	1) variables stockant les étendues des tableaux
INTEGER :: NX,NY
! 2) variables pour les tableaux dynamiques
INTEGER :: errAlloc                                         ! entier pour vérification des allocation/libération de mémoire
INTEGER, DIMENSION(:), ALLOCATABLE :: TabDyn                ! premier tableau (1 dimension)
DOUBLE PRECISION, DIMENSION(:,:), ALLOCATABLE :: MatDyn     ! second tableau (2 dimensions)

PRINT*,'***********************************************************************************'
PRINT*,'                                DEBUT DU PROGRAMME'

! Déroulement du programme
!=================================

! 1) lecture des tailles désirées
PRINT*,'Quelle taille voulez-vous pour le premier tableau ?'
READ(*,*,iostat = errAlloc)NX
print*, errAlloc

ALLOCATE(TabDyn(NX), stat = errAlloc)
PRINT*,'  ==> Statut allocation memoire TabDyn (0 si ok) : ',errAlloc

PRINT*,'Pour le deuxieme tableau : que vaut la premiere etendue ?'
READ(*,*)NX
PRINT*,'Pour le deuxieme tableau : que vaut la seconde etendue ?'
READ(*,*)NY

ALLOCATE(MatDyn(NX,NY), stat = errAlloc)
PRINT*,'  ==> Statut allocation memoire MatDyn (0 si ok) : ',errAlloc

! 2) Affichage des tableaux correspondants
PRINT*,'==================================================================='

TabDyn(:) = 0
PRINT*,'Tableau TabDyn : ',TabDyn

MatDyn(:,:) = 1.D0
PRINT*,'Tableau MatDyn : ',MatDyn

! 3) Libération de la mémoire
PRINT*,'==================================================================='

DEALLOCATE(TabDyn,MatDyn, stat = errAlloc)
PRINT*,'Statut liberation de memoire (0 si ok) :',errAlloc

! 4) Fin du programme principal
PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'

END PROGRAM TableauDynamique1
