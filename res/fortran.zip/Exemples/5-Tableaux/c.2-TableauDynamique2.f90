!----------------------------------------------------
!          Programme de presentation de tableaux
!          dynamiques contenant des types dérivés           
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauDynamique2
IMPLICIT NONE

! Déclaration des variables 
!=================================
INTEGER :: N,errAlloc
TYPE Point
DOUBLE PRECISION :: x,y,z
character :: a
END TYPE
Type(Point), DIMENSION(:), ALLOCATABLE :: courbe

! Coeur du programme principal 
!=================================
! 1) Affichage
PRINT*,'***********************************************************************************'
PRINT*,'                                DEBUT DU PROGRAMME'

! 2) Lecture du nombre de points et affectation de la mémoire
PRINT*,'Combien de points possede votre courbe ?'
READ(*,*)N

ALLOCATE(courbe(N), stat = errAlloc)
PRINT*,'   ==> Statut allocation memoire courbe (0 si ok) : ',errAlloc

! 3) Affichage des différents éléments du tableau, chacun contenant un type "Point"
PRINT*,'==================================================================='
courbe(1)%x = 0.D0
courbe(1)%y = 0.D0
courbe(1)%z = 0.D0
courbe(1)%a = "t"
PRINT*,'Point 1 =',courbe(1)%x,courbe(1)%y,courbe(1)%y, courbe(1)%a
courbe(2)%x = 1.D0
courbe(2)%y = 0.D0
courbe(2)%z = 0.D0
courbe(2)%a = "0"
PRINT*,'Point 2 =',courbe(2)%x,courbe(2)%y,courbe(2)%z, courbe(2)%a
courbe(3)%x = 0.D0
courbe(3)%y = 1.D0
courbe(3)%z = 0.D0
PRINT*,'Point 3 =',courbe(3)%x,courbe(3)%y,courbe(3)%z
courbe(4)%x = 0.D0
courbe(4)%y = 0.D0
courbe(4)%z = 1.D0
PRINT*,'Point 4 =',courbe(4)%x,courbe(4)%y,courbe(4)%z
PRINT*,'Point 5 =',courbe(5)%x,courbe(5)%y,courbe(5)%z
PRINT*,'Point 6 =',courbe(6)%x,courbe(6)%y,courbe(6)%z  ! Remarque : attention aux NOTIONS FONDAMENTALES de DEBORDEMENT...
PRINT*,'==================================================================='


! 4) Fin du programme
DEALLOCATE(courbe, stat = errAlloc)
PRINT*,'Statut liberation de memoire (0 si ok) :',errAlloc

PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'

END PROGRAM TableauDynamique2