!----------------------------------------------------
!          Exemples d'initialisation des
!             variables d'un tableau
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauInitialisation
IMPLICIT NONE

! Déclaration des variables 
!=================================
INTEGER, DIMENSION(10) :: Vec
INTEGER, DIMENSION(10) :: Vec2
INTEGER, DIMENSION(5,5) :: Mat
INTEGER, DIMENSION(7,7) :: Mat2

! Déroulement du programme
!=================================

! 1) Affichage de début
PRINT*,'***********************************************************************************'
PRINT*,'                                DEBUT DU PROGRAMME'

! 2) Initialisation "par morceaux continus" 
Vec(1:5) = -1
Vec(6:10) = +1
PRINT*,'Vec : ',Vec

!3) Initialisation globale puis "par morceaux discontinus"
Vec2 = 0
Vec2(1:10:2) = +1
PRINT*,'Vec2 : ',Vec2

Mat = 0
Mat(1:5:2,2:4:2) = +1
PRINT*,'Mat : '
PRINT*,Mat(1,:)
PRINT*,Mat(2,:)
PRINT*,Mat(3,:)
PRINT*,Mat(4,:)
PRINT*,Mat(5,:)

Mat2 = 0
Mat2( (/1,2,6/) , (/3,7/) ) = +1
PRINT*,'Mat2 : '
PRINT*,Mat2(1,:)
PRINT*,Mat2(2,:)
PRINT*,Mat2(3,:)
PRINT*,Mat2(4,:)
PRINT*,Mat2(5,:)
PRINT*,Mat2(6,:)
PRINT*,Mat2(7,:)

! 1) Affichage de fin
PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'


END PROGRAM TableauInitialisation