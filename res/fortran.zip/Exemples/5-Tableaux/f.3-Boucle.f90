!----------------------------------------------------
!       Programme de demonstration sur les
!          boucles itératives (FORALL)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM BouclePourTableaux
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i,j
INTEGER, DIMENSION(5) :: Vec1,Vec2
INTEGER, DIMENSION(5,5) :: Mat


! Programme principal
!=================================

FORALL (i=1:5)
  Vec1(i) = -1
  Vec2(i) = +1
END FORALL

PRINT*,"Vec1 = ",Vec1
PRINT*,"Vec2 = ",(Vec2(i),i=1,5)

PRINT*,""

FORALL (i=1:5, j=1:5)
  Mat(i,j) = i*j
END FORALL

PRINT*,"Mat = "
DO i=1,5
  PRINT*,(Mat(i,j),j=1,5)
ENDDO



PRINT*,"Mat = ",Mat

STOP
END PROGRAM BouclePourTableaux




