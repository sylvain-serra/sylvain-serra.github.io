!----------------------------------------------------
!          Programme de presentation
!           des tableaux statiques 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauStatique1
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER, DIMENSION(5) :: TabEntier		! Déclaration d'un tableau d'entiers de dimension 1 avec 5 éléments
REAL, DIMENSION(2,3) :: TabReelSimple	! Déclaration d'un tableau de réels de dimension 2 avec une étendue de 2 et 3

! Coeur du programme
!=================================

! 1) Initialisation
TabEntier(1) = 1
TabEntier(2) = 2
TabEntier(3) = 3
TabEntier(4) = 4
TabEntier(5) = 5

TabReelSimple = 1.E0

! 2) Affichage
PRINT*,'Proprietes du tableau d''entiers TabEntier'
PRINT*,'Tableau complet :',TabEntier
PRINT*,'   1er element  : ',TabEntier(1)
PRINT*,'   3eme element : ',TabEntier(3)

PRINT*,'Proprietes du tableau de reels TabReelSimple'
PRINT*,'Tableau complet : ',TabReelSimple
PRINT*,'   element(1,1) : ',TabReelSimple(1,1)
PRINT*,'   element(1,3) : ',TabReelSimple(1,3)

STOP
END PROGRAM TableauStatique1
