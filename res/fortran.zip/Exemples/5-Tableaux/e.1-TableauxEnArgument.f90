!----------------------------------------------
!       Exemples de programme utilisant des sous-programmes 
!           dont l'un des arguments est un tableau
!         
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!----------------------------------------------

PROGRAM SousProgrammeAvecTableauEnArgument
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER, PARAMETER :: dim1=5, dim2=2
DOUBLE PRECISION, DIMENSION(10) :: tailleDoigtsMain
INTEGER, DIMENSION(dim1, dim2) :: Matrice
REAL, DIMENSION(:), ALLOCATABLE :: tableauDynamique

! Déclaration de l'interface
! nb: placee ici pour plus de lisibilite, mais il serait preferable de la placer dans un module...
!=================================
INTERFACE passageImpliciteTableaux
	SUBROUTINE passageTableauImplicite(tableau)
	IMPLICIT NONE
	REAL, DIMENSION(:), INTENT(INOUT) :: tableau
	END SUBROUTINE passageTableauImplicite
END INTERFACE passageImpliciteTableaux


! Programme principal
!=================================

! 1) Exemple de passage d'un tableau a un sous-programme de maniere explicite rigide
CALL passageTableauExpliciteRigide(tailleDoigtsMain)
PRINT*,""
PRINT*,tailleDoigtsMain

! 2) Exemple de passage d'un tableau a un sous-programme de maniere explicite ajustable
CALL passageTableauExpliciteAjustable(Matrice, dim1, dim2)
PRINT*,""
PRINT*,Matrice

! 3) Exemple de passage d'un tableau a un sous-programme de maniere implicite
ALLOCATE(tableauDynamique(dim1*dim2*dim2))

CALL passageTableauImplicite(tableauDynamique)
PRINT*,""
PRINT*,tableauDynamique
DEALLOCATE(tableauDynamique)


STOP


END PROGRAM SousProgrammeAvecTableauEnArgument



! Passage de tableau en argument : protocole explicite rigide
!----------------------------------------------
SUBROUTINE passageTableauExpliciteRigide(tableau)
IMPLICIT NONE
! 1) Arguments
DOUBLE PRECISION, DIMENSION(10) :: tableau
!  2) Variables locales de la subroutine
INTEGER :: i

DO i=1,10
	tableau(i) = i*1.5D0
ENDDO

END SUBROUTINE passageTableauExpliciteRigide


! Passage de tableau en argument : protocole explicite ajustable
!----------------------------------------------
SUBROUTINE passageTableauExpliciteAjustable(tableau, premiereDimension, secondeDimension)
IMPLICIT NONE
! 1) Arguments
INTEGER :: premiereDimension, secondeDimension
INTEGER, DIMENSION(premiereDimension, secondeDimension) :: tableau
!  2) Variables locales de la subroutine
INTEGER :: i,j

DO i=1,premiereDimension
	DO j=1,secondeDimension
		tableau(i,j) = i*j
	ENDDO
ENDDO

END SUBROUTINE passageTableauExpliciteAjustable


! Passage de tableau en argument : protocole implicite
! nb: besoin de l'interface definie en preambule
!----------------------------------------------
SUBROUTINE passageTableauImplicite(tableau)
IMPLICIT NONE
! 1) Arguments
REAL, DIMENSION(:), INTENT(INOUT) :: tableau
!  2) Variables locales de la subroutine
INTEGER :: N,i

N = SIZE(tableau)

DO i=1,N
	tableau(i) = i
ENDDO


END SUBROUTINE passageTableauImplicite

 

