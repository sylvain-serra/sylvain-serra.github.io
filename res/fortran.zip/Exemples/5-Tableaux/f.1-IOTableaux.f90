!----------------------------------------------
!        Exemples de programme Fortran
!         ecrit dans le format libre
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM LectureEcritureTableaux
IMPLICIT NONE

! Déclaration
!=================================
REAL, DIMENSION(3,1:3) :: Tab

! Coeur du programme
!=================================

! Test d'écriture de tableaux

WRITE(*,*)'Ecriture du tableau complet'
Tab(:,:) = 0.E0
WRITE(*,*)Tab

WRITE(*,*)'Ecriture d''une dimension du tableau'
Tab(1,:) = 1.E0
Tab(2,:) = 2.E0
Tab(3,:) = 3.E0
WRITE(*,*)Tab(:,1)
WRITE(*,*)Tab

WRITE(*,*)'Ecriture d''un unique element du tableau'
Tab(3,3) = 99.99E0
WRITE(*,*)Tab(3,3)
WRITE(*,*)Tab

WRITE(*,*)'---------------------------'

! Test de lecture dans un fichier

OPEN(UNIT=10,FILE='fichiertableau.txt',STATUS='UNKNOWN')

Tab(:,:) = 0.E0
WRITE(*,*)'Lecture du tableau complet'
READ(10,*)Tab(:,:)
WRITE(*,*)Tab

Tab(:,:) = 0.E0
WRITE(*,*)"Lecture d''une dimension du tableau"
READ(10,*)Tab(1,:)
WRITE(*,*)Tab

Tab(:,:) = 0.E0
WRITE(*,*)"Lecture d''un unique element du tableau"
READ(10,*)Tab(1,1),Tab(2,2)
WRITE(*,*)Tab

CLOSE(10)

STOP
END PROGRAM LectureEcritureTableaux
