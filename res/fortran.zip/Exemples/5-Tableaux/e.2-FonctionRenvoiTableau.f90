!----------------------------------------------
!       Exemples de programme utilisant une fonction
!         qui renvoit un tableau en sortie
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!----------------------------------------------

PROGRAM FonctionRenvoiTableau
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER, PARAMETER :: N = 5, M=3
DOUBLE PRECISION, DIMENSION(10) :: tableau1
DOUBLE PRECISION, DIMENSION(:), ALLOCATABLE :: tableauAvance
DOUBLE PRECISION, DIMENSION(N, M) :: tableau2
DOUBLE PRECISION, DIMENSION(N) :: Moyennetableau2
INTEGER :: nlocal

! Déclaration des interfaces
!=================================
INTERFACE fonctionsRenvoyantUnTableau

	FUNCTION remplissageCroissant()
		DOUBLE PRECISION, DIMENSION(10) :: remplissageCroissant
	END FUNCTION remplissageCroissant
	
	FUNCTION remplissageCroissantAvance(N)
		INTEGER, INTENT(IN) :: N
		DOUBLE PRECISION, DIMENSION(N) :: remplissageCroissantAvance
	END FUNCTION remplissageCroissantAvance
	
	FUNCTION moyenne(tab, N , M)
		INTEGER :: N, M
		DOUBLE PRECISION, DIMENSION(N, M), INTENT(IN) :: tab
		DOUBLE PRECISION, DIMENSION(N) :: moyenne
	END FUNCTION moyenne
	
END INTERFACE fonctionsRenvoyantUnTableau



! Programme principal
!=================================

! 1) Exemple de passage d'un tableau de maniere explicite rigide
tableau1 = 0.D0

tableau1 = remplissageCroissant()

PRINT*
PRINT*,tableau1


! 2) Exemple de passage d'un tableau de maniere explicite ajustable

! a)
PRINT*
PRINT*,"Entrer la dimension du tableau a renvoyer"
READ(*,*)nlocal

ALLOCATE(tableauAvance(nlocal))

tableauAvance = remplissageCroissantAvance(nlocal)
PRINT*,tableauAvance

DEALLOCATE(tableauAvance)

! b) 
tableau2(1,:) = (/12.D0, 14.D0, 16.D0/)
tableau2(2,:) = (/10.D0, 8.D0, 6.D0/)
tableau2(3,:) = (/16.D0, 18.D0, 20.D0/)
tableau2(4,:) = (/2.D0, 4.D0, 6.D0/)
tableau2(5,:) = (/11.D0, 7.D0, 16.D0/)

Moyennetableau2 = moyenne(tableau2, N , M)

PRINT*
PRINT*,Moyennetableau2



STOP

END PROGRAM FonctionRenvoiTableau




FUNCTION remplissageCroissant()
IMPLICIT NONE
! Déclaration
! 1) Arguments
!    ... aucun
! 2) Type de la fonction
DOUBLE PRECISION, DIMENSION(10) :: remplissageCroissant
! 3) Variables locales de la fonction
INTEGER :: i

! Coeur de la fonction
DO i = 1,10
	remplissageCroissant(i) = i*10.D0
ENDDO

END FUNCTION remplissageCroissant




FUNCTION remplissageCroissantAvance(N)
IMPLICIT NONE
! Déclaration
! 1) Arguments
INTEGER, INTENT(IN) :: N
! 2) Type de la fonction
DOUBLE PRECISION, DIMENSION(N) :: remplissageCroissantAvance
! 3) Variables locales de la fonction
INTEGER :: i

! Coeur de la fonction
DO i = 1,N
	remplissageCroissantAvance(i) = i
ENDDO

END FUNCTION remplissageCroissantAvance




FUNCTION moyenne(tab, N , M)
IMPLICIT NONE
! Déclaration
! 1) Arguments
INTEGER, INTENT(IN) :: N, M
DOUBLE PRECISION, DIMENSION(N, M), INTENT(IN) :: tab
! 2) Type de la fonction
DOUBLE PRECISION, DIMENSION(N) :: moyenne
! 3) Variables locales de la fonction
INTEGER :: i,j

! Coeur de la fonction
moyenne = 0.D0

DO i = 1,N
	DO j = 1,M
		moyenne(i) = moyenne(i) + tab(i,j)
	ENDDO
	moyenne(i) = moyenne(i)/M
ENDDO

END FUNCTION moyenne

