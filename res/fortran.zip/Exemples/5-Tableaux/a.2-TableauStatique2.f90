!----------------------------------------------------
!          Programme de presentation
!           des tableaux statiques 
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------------

PROGRAM TableauStatique2
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER, DIMENSION(-3:3) :: TabEntier2		! Déclaration d'un tableau d'entiers de dimension 1 avec 5 éléments
REAL, DIMENSION(-1:1,4) :: TabReelSimple2	! Déclaration d'un tableau de réels de dimension 2 avec une étendue de 3 et 5

! Programme principal
!=================================

! 1) Initialisation

TabEntier2(:) = 1

TabReelSimple2(:,:) = 1.E0

! 2) Affichage

PRINT*,"Proprietes du tableau d'entiers TabEntier2"
PRINT*,'Tableau complet : ',TabEntier2
PRINT*,'   1er element  : ',TabEntier2(-3)
PRINT*,'   3eme element : ',TabEntier2(0)
PRINT*,'   7eme element : ',TabEntier2(3)

PRINT*,'Proprietes du tableau de reels TabReelSimple2'
PRINT*,'Tableau complet : ',TabReelSimple2
PRINT*,'   element(1,1) : ',TabReelSimple2(-1,1)
PRINT*,'   element(2,3) : ',TabReelSimple2(0,3)

STOP
END PROGRAM TableauStatique2