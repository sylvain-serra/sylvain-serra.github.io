!----------------------------------------------------
!       Programme de demonstration sur les
!          tests conditionnels (WHERE)            
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 16 Aout 2013
!----------------------------------------------------

PROGRAM TestConditionnelSurTableaux
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER, DIMENSION(-5:5) :: Tableau
INTEGER, DIMENSION(11) :: Tableau2

! Programme principal
!=================================

Tableau(-5:5:2) = -1
Tableau(-4:4:2) = +1

PRINT*,'Affichage du tableau 1 :'
PRINT*,Tableau
PRINT*,'Affichage du tableau 2 :'
PRINT*,Tableau2

PRINT*,"Calcul..."

WHERE (Tableau < 0)
  Tableau2 = 0
ELSEWHERE
  Tableau2 = Tableau
ENDWHERE

PRINT*,'Affichage du tableau 1 :'
PRINT*,Tableau
PRINT*,'Affichage du tableau 2 :'
PRINT*,Tableau2

END PROGRAM TestConditionnelSurTableaux
