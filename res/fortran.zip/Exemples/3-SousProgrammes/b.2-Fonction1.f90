!----------------------------------------------
!       Exemples de programme utilisant
!         une maPremiereFonctiontion (très) simple
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM maPremiereFonctiontion1
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION :: x,y,z
DOUBLE PRECISION :: toto
DOUBLE PRECISION :: maPremiereFonction


! Programme principal
!=================================
x = 1.D0
y = 2.D0
z = 3.D0

PRINT*,'x = ',x
PRINT*,'y = ',y
PRINT*,'z = ',z
PRINT*,''

PRINT*,"Premier essai de la fonction"

toto = maPremiereFonction(x,y,z)
PRINT*,'     valeur de la fonction = ',toto

PRINT*,"Modification du role des arugments..."

PRINT*,"     valeur de la fonction = ",maPremiereFonction(z,y,x)

STOP
END PROGRAM maPremiereFonctiontion1



!----------------------------------------------
!----------------------------------------------
!     DEFINITION DES maPremiereFonctionTIONS EXTERNES
!----------------------------------------------
!----------------------------------------------



! maPremiereFonctiontion unique du code (description triviale)
!----------------------------------------------
FUNCTION maPremiereFonction(a,b,c)
IMPLICIT NONE
! Déclaration
! 1) Arguments
DOUBLE PRECISION,	INTENT(IN)	::	a,b,c 		! arguments (lecture seule)
! 2) Type de la maPremiereFonctiontion
DOUBLE PRECISION	::	maPremiereFonction 					! type retourné par la maPremiereFonctiontion
! 3) Variables locales de la maPremiereFonctiontion
DOUBLE PRECISION :: local						

! Coeur de la maPremiereFonctiontion
	local = a**2
	maPremiereFonction = a+b*c + local

END FUNCTION maPremiereFonction


