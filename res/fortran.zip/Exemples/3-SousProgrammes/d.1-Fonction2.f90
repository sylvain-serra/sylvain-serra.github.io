!----------------------------------------------
!    					Exemples de programme utilisant une
!       					fonction un peu particulière
!        (renvoyant une structure, i.e. une variable de type complexe -définie par le programmeur-)
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM FonctionRenvoyantUneVariableDeTypeStructureComplexe
! Déclaration des modules importés
!=================================
USE definitionTypePoint

! Déclaration des variables
!=================================
IMPLICIT NONE
TYPE(Point) :: A
TYPE(Point) :: Origin

! Coeur du programme
!=================================
A%x = 1.D0
A%y = 2.D0
A%z = 3.D0
PRINT*,"A = ",A%x,A%y,A%z
	
A = Origin()							! Appel d'une fonction renvoyant une valeur de type "Point"
PRINT*,"A = ",A%x,A%y,A%z
	
	
STOP



END PROGRAM FonctionRenvoyantUneVariableDeTypeStructureComplexe




FUNCTION Origin()
	USE definitionTypePoint
	IMPLICIT NONE
	! 1) Type de la fonction
	TYPE(Point) :: Origin

	! 2) Coeur de la fonction
	Origin%x = 0.D0
	Origin%y = 0.D0
	Origin%z = 0.D0
END FUNCTION Origin