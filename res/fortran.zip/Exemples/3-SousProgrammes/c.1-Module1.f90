!----------------------------------------------
!      Exemple de module (très) simple
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

MODULE monPremierModule
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION, PARAMETER :: PI = ACOS(-1.D0)

END MODULE monPremierModule


