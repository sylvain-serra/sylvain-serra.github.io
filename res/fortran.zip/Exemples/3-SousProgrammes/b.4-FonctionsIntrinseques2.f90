!----------------------------------------------------
!     Programme de demonstration de quelques
!       fonctions intrinsèques du Fortran  
!   (fonctions "de texte" et pour les tableaux)    
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 18 Aout 2013
!----------------------------------------------------

PROGRAM FonctionsIntrinseques2
IMPLICIT NONE

! Déclaration
!=================================
CHARACTER(LEN=6) :: chaineDeCaracteres1
CHARACTER(LEN=10) :: chaineDeCaracteres2
INTEGER, DIMENSION(3,2) :: Tab

PRINT*,'***********************************************************************************'
PRINT*,'           TESTS DE DIVERSES FONCTIONS INTRINSEQUES DU LANGAGE FORTRAN II'
PRINT*,"***********************************************************************************"
PRINT*,'                                DEBUT DU PROGRAMME '



! Premiere partie : fonctions pour les chaines de caractere
!-----------------------------------------------------------------------------

PRINT*,' 1) Fonctions pour les chaînes de caractères'

chaineDeCaracteres1 = "EN GTI"
chaineDeCaracteres2 = "  "//"EN GTI"//"  "

! Specificites de la chaine
PRINT*,'Le premier mot stocke est : ',chaineDeCaracteres1
PRINT*,'Sa longueur vaut  :',LEN(chaineDeCaracteres1)
PRINT*,''
PRINT*,'Le second mot stocke est : ',chaineDeCaracteres2
PRINT*,'Sa longueur vaut  :',LEN(chaineDeCaracteres2)
PRINT*,'Sa longueur sans les blancs de fin vaut  :',LEN_TRIM(chaineDeCaracteres2)
PRINT*,'Sa longueur sans aucun blanc vaut        :',LEN_TRIM(ADJUSTL(chaineDeCaracteres2))


PRINT*,' ================================================================ '

! Seconde partie : fonctions pour les tableaux
!-----------------------------------------------------------------------------

PRINT*,' 2) Fonctions pour les tableaux'

Tab(:,:) = 3
Tab(1:2,:) = 1
PRINT*,'Le tableau a pour valeurs :'
PRINT*,Tab
PRINT*,'Profil de Tab : ',SHAPE(Tab)
PRINT*,'Taille totale : ',SIZE(Tab)
PRINT*,'Taille totale de la premiere dimension : ',SIZE(Tab,1)
PRINT*,'Taille totale de la seconde dimension  : ',SIZE(Tab,2)

PRINT*,''
PRINT*,'Somme des elements = ',SUM(Tab)
PRINT*,'Somme des elements de la premiere dimension = ',SUM(Tab,1)
PRINT*,'Produit des elements = ',PRODUCT(Tab)

PRINT*,''
PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'


END PROGRAM FonctionsIntrinseques2
