!----------------------------------------------
!         Exemple de programme utilisant 
!                une procédure
! nb: programme (volontairement) FAUX
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM ProcedureSimple
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i
DOUBLE PRECISION :: x

! Coeur du programme
!------------------------------------------------------------------------------------------
! 1/ Initialisation des variables
PRINT*,"Saisir un nombre entier:"
READ(*,*)i

PRINT*,"Saisir un nombre reel:"
READ(*,*)x

! 2/ Appel de la procédure 
PRINT*,"Appel subroutine"

PRINT*,"------------------------------------------------"

CALL maPremiereProcedure(i,x)				! ERREUR: le type des variables et des arguments ne correspond pas [solution possible: maPremiereProcedure(x,i)]
CALL maPremiereProcedure(i,x,y)				! ERREUR: le nombre d'arguments ne correspond pas avec la définition de la procédure

PRINT*,"------------------------------------------------"

PRINT*,"Retour programme principal"

STOP

END PROGRAM ProcedureSimple


! Procédures externes
!------------------------------------------------------------------------------------------

SUBROUTINE maPremiereProcedure(a,b)
IMPLICIT NONE
! 1) Arguments
DOUBLE PRECISION, INTENT(IN) :: a       			! argument entier, non modifiable
INTEGER, INTENT(IN) :: b     						! argument réel, non modifiable

! 2) Coeur de la subroutine
PRINT*,"La valeur des arguments de la subroutine est:"
PRINT*,"Premier argument:",a
PRINT*,"Second argument: ",b

END	SUBROUTINE	maPremiereProcedure



