!----------------------------------------------------
!          Programme de demonstration de quelques
!            fonctions intrinsèques du Fortran   
!               (fonctions "numériques")   
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 20 Juillet 2014
!----------------------------------------------------

PROGRAM FonctionsIntrinseques1
IMPLICIT NONE

! Déclaration
!=================================
REAL :: x
DOUBLE PRECISION :: y

PRINT*,"***********************************************************************************"
PRINT*,"           TESTS DE DIVERSES FONCTIONS INTRINSEQUES DU LANGAGE FORTRAN "
PRINT*,"***********************************************************************************"
PRINT*,"                                DEBUT DU PROGRAMME "
PRINT*,""
PRINT*,""


! Premiere partie : fonctions arithmétiques usuelles
!-----------------------------------------------------------------------------

! Particularites des fonctions trigonometriques et precision machine (troncature naturelle puisque Pi est irrationnelle...)
PRINT*,'1) Fonctions trigonometriques'

PRINT*

x = ACOS(-1.0)
PRINT*,"Exemple en simple precision"
PRINT*,'    Pi vaut          : ',x
PRINT*,'    son cosinus vaut : ',COS(x)
PRINT*,'    son sinus vaut   : ',SIN(x)

PRINT*

y = ASIN(1.0)
PRINT*,"Exemple en double precision"
PRINT*,'    Pi/2 vaut        : ',y
PRINT*,'    son cosinus vaut : ',COS(y)
PRINT*,'    son sinus vaut   : ',SIN(y)

y = 1.23D0
PRINT*,''
PRINT*,'    y = ',y
PRINT*,'    cosh(y) = ',COSH(y)
PRINT*,'    sinh(y) = ',SINH(y)
PRINT*,'    tanh(y) = ',TANH(y)

PRINT*,""

! Fonctions de puissances
PRINT*,'2) Fonctions de puissance'
x = -1.E0
y = 2.D0
PRINT*,'    x          = ',x
PRINT*,'    |x|        = ',ABS(x)
PRINT*,'    exp(x)     = ',EXP(x)
PRINT*,'    ln(exp(x)) = ',LOG(EXP(x))
PRINT*,'    y          = ',y
PRINT*,'    racine(y)  = ',SQRT(y)

PRINT*,""

! Fonctions comparatives : deux arguments requis
PRINT*,'3) Fonctions ''comparatives'''
x = -16.E0
y = 3.D0
PRINT*,'    MOD(x,y)    = ',MOD(x,y)
PRINT*,'    MODULO(x,y) = ',MODULO(x,y)

PRINT*,''
PRINT*,'   ================================================================   '
PRINT*,''

! Seconde partie : fonctions de conversion
!-----------------------------------------------------------------------------

x = 1.23E0
y = 4.56D0
  
PRINT*,'x = ',x
PRINT*,'y = ',y

PRINT*,''
PRINT*,'1) Fonctions de conversion dans un autre type'
PRINT*,'    ----- Transformation en entier -----'
PRINT*,'    INT(x) = ',INT(x)
PRINT*,'    INT(y) = ',INT(y)
PRINT*,'    ----- Transformation en complexe -----'
PRINT*,'    CMPLX(x) = ',CMPLX(x)
PRINT*,'    CMPLX(y) = ',CMPLX(y)
PRINT*,'    DCMPLX(x) = ',DCMPLX(x)
PRINT*,'    DCMPLX(y) = ',DCMPLX(y)

PRINT*,''
PRINT*,'2) Fonctions d''approximation'
PRINT*,'    ----- Troncature -----'
PRINT*,'    AINT(x) = ',AINT(x)
PRINT*,'    AINT(y) = ',AINT(y)
PRINT*,'    ----- Arrondi -----'
PRINT*,'    ANINT(x) = ',ANINT(x)
PRINT*,'    ANINT(y) = ',ANINT(y)
PRINT*,'    ----- Entier inferieur le plus proche -----'
PRINT*,'    FLOOR(x) = ',FLOOR(x)
PRINT*,'    FLOOR(y) = ',FLOOR(y)
PRINT*,'    ----- Entier superieur le plus proche -----'
PRINT*,'    CEILING(x) = ',CEILING(x)
PRINT*,'    CEILING(y) = ',CEILING(y)


PRINT*,''
PRINT*,'                                 FIN DU PROGRAMME'
PRINT*,'***********************************************************************************'


END PROGRAM FonctionsIntrinseques1
