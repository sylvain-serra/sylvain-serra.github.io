!----------------------------------------------
!      Exemple de module (très) simple
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

MODULE definitionTypePoint
IMPLICIT NONE

! Définition d'un nouveau type de variable pour nos besoins
!=================================
TYPE Point
	DOUBLE PRECISION :: x,y,z			! 3 champs réels (pour chaque coordonnée)
END TYPE 

END MODULE definitionTypePoint


