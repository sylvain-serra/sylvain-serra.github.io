!----------------------------------------------
!         Exemple de programme faisant 
!            appel à des modules
! nb: compilation ayant besoin de transmettre les fichiers contenant les détails de chaque module
! commande: "gfortran c.1-Module1.f90 c.1-Module2.f90 c.1-ModuleUtilisations.f90 -o run"
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM UnExempleDeModule
! Déclaration des modules importés
!=================================
USE monPremierModule			! noms (fortran) des modules utilisés
USE ModulePlusComplet			! ATTENTION : ce n'est pas le nom des fichiers contenant leur définition

! Déclaration des variables
!=================================
IMPLICIT NONE
DOUBLE PRECISION :: gamma
DOUBLE PRECISION :: T,c

! Coeur du programme
!=================================

PRINT*,"1/ Utilisation du premier module"
PRINT*,"Pi = ",PI

PRINT*,"2/ Utilisation du second module"
PRINT*,"Donner une temperature (en K) :"
READ(*,*)T
gamma = 1.4D0
CALL VitesseDuSon(c,T,gamma)
PRINT*,"Vitesse du son dans l'air (en m/s) = ",c

END PROGRAM UnExempleDeModule


