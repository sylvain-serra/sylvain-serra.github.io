!----------------------------------------------
!         Exemple de programme utilisant 
!          une procédure et illustrant
!    la différence entre argument et variable
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM ProcedureSimple
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i

! Coeur du programme
!------------------------------------------------------------------------------------------
! 1/ Initialisation des variables
PRINT*,"Saisir un nombre entier:"
READ(*,*)i

! 2/ Appel de la procédure 
PRINT*,"Valeur de la variable globale:",i

PRINT*,"------------------------------------------------"

CALL maProcedure(i)

PRINT*,"------------------------------------------------"

PRINT*,"Valeur de la variable globale:",i

STOP

END PROGRAM ProcedureSimple


! Procédures externes
!------------------------------------------------------------------------------------------

SUBROUTINE maProcedure(a)
IMPLICIT NONE
! 1) Arguments
INTEGER, INTENT(INOUT) :: a       			! argument entier, non modifiable
! 2) Variable locales
INTEGER :: i								! variable locale (elle n'a rien à voir avec le "i" du programme principal)

i = 3*a

! 3) Coeur de la subroutine
PRINT*,"Valeur de la variable 'i' du programme principal (i.e. l'argument)   : ",a

PRINT*,"Valeur de la variable 'i' du sous-programme (i.e. la variable locale): ",i

END	SUBROUTINE	maProcedure



