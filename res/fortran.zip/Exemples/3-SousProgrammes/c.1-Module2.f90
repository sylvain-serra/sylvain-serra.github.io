!----------------------------------------------
!      Exemple de module plus complet
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

MODULE ModulePlusComplet
IMPLICIT NONE

! Variables
!-------------------------------------------------------
DOUBLE PRECISION, PARAMETER :: Rgazparfait = 287.D0

! Procédures
!-------------------------------------------------------
CONTAINS

! 1) Vitesse du son pour un gaz parfait 
!    nb: exemple purement stylistique, il serait préférable ici de créer une fonction plutôt qu'une subroutine
SUBROUTINE VitesseDuSon(c,T,gamma)
	IMPLICIT NONE
	! arguments
	DOUBLE PRECISION, INTENT(out) :: c
	DOUBLE PRECISION, INTENT(in) :: T,gamma
	! coeur
	c = DSQRT(gamma*Rgazparfait*T)
END SUBROUTINE VitesseDuSon

END MODULE ModulePlusComplet


