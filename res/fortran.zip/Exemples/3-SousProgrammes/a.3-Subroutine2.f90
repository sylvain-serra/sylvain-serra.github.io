!----------------------------------------------
!         Exemple de programme utilisant 
!                une procédure
! nb: programme (volontairement) FAUX
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM ProcedureSimple
IMPLICIT NONE

! Déclaration des variables
!=================================
INTEGER :: i

! Coeur du programme
!------------------------------------------------------------------------------------------
! 1/ Initialisation des variables
PRINT*,"Saisir un nombre entier:"
READ(*,*)i

! 2/ Appel de la procédure 
PRINT*,"Valeur de la variable globale:",i

PRINT*,"------------------------------------------------"

CALL maProcedure(i)

PRINT*,"------------------------------------------------"

PRINT*,"Valeur de la variable globale:",i

STOP

END PROGRAM ProcedureSimple


! Procédures externes
!------------------------------------------------------------------------------------------

SUBROUTINE maProcedure(a)
IMPLICIT NONE
! 1) Arguments
INTEGER, INTENT(IN) :: a       			! argument entier, non modifiable

! 2) Coeur de la subroutine
PRINT*,"Valeur initiale de l'argument: ",a
a=a+10													! ERREUR: modification de la valeur de la variable passée en argument
PRINT*,"Valeur finale de l'argument: ",a

END	SUBROUTINE	maProcedure



