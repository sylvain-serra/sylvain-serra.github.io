!----------------------------------------------
!       Exemples de programme utilisant
!         une fonction (très) simple
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2018
!----------------------------------------------

PROGRAM fonction1
IMPLICIT NONE

! Déclaration des variables
!=================================
DOUBLE PRECISION :: x,y,z
DOUBLE PRECISION :: maPremiereFonction


! Programme principal
!=================================
! 1) Initialiation des variables
PRINT*,"Saisir un premier chiffre"
READ(*,*)x

PRINT*,"Saisir un premier chiffre"
READ(*,*)y

! 2) Utilisation d'une fonction (qui calcule la somme de deux nombres)
z = maPremiereFonction(x,y)

PRINT*,"Valeur de z:",z

STOP
END PROGRAM fonction1



!----------------------------------------------
!----------------------------------------------
!     DEFINITION DES FONCTIONS EXTERNES
!----------------------------------------------
!----------------------------------------------



! Fonction unique du code (description triviale)
!----------------------------------------------
FUNCTION maPremiereFonction(a,b)
IMPLICIT NONE
! Déclaration
! 1) Arguments
DOUBLE PRECISION,	INTENT(IN)	::	a,b			! arguments (lecture seule)
! 2) Type de la fonction
DOUBLE PRECISION	::	maPremiereFonction 		! type retourné par la fonction					

! Coeur de la fonction
	maPremiereFonction = a+b

END FUNCTION maPremiereFonction


