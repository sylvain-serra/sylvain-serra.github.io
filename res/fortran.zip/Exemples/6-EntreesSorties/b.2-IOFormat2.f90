!----------------------------------------------
!        Exemples de programme Fortran
!      pour la manipulation d'un fichier
!           et une lecture formatée
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM SpecificationFormat2
IMPLICIT NONE

! Déclaration
!=================================
DOUBLE PRECISION :: x,y
CHARACTER(LEN=11) :: formatEcriture


! Coeur du programme
!=================================

OPEN(UNIT=10,FILE='fichierformat.txt',STATUS='UNKNOWN')

READ(10,*)x,y
PRINT*,x,y

READ(10,FMT=100)x,y
PRINT*,x,y

formatEcriture='(F3.1,F3.1)'
READ(10,FMT=formatEcriture)x,y
PRINT*,x,y

CLOSE(10)

100 FORMAT(2(F3.1,x))


STOP
END PROGRAM SpecificationFormat2
