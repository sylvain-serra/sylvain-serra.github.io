!----------------------------------------------
!        Exemple de programme Fortran
!      pour la manipulation d'un fichier
!       montrant les dangers et risques
!       de ne pas spécifier les usages
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM EcritureFichierExistant
IMPLICIT NONE

PRINT*,'OUVERTURE DU FICHIER'

OPEN(UNIT=10,FILE='fichierEcrase.txt',STATUS='UNKNOWN')

PRINT*,'ECRITURE DANS LE FICHIER'
WRITE(10,*)'YOUHOU JE FAIS CE QUE JE VEUX'
WRITE(10,*)'    JE DETRUIS TOUT '

CLOSE(10)

PRINT*,'FERMETURE DU FICHIER'

END PROGRAM EcritureFichierExistant
