!----------------------------------------------
!        Exemples de programme Fortran
!      pour la manipulation d'un fichier
!           et une écriture formatée
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM SpecificationFormat
IMPLICIT NONE

! Déclaration
!=================================
LOGICAL :: boolen
INTEGER :: i,j,k
DOUBLE PRECISION :: x,y,z
CHARACTER(LEN=6) :: nom

! Coeur du programme
!=================================

PRINT*,'Impression de booleen'
boolen = .TRUE.
WRITE(*,'(L1)')boolen
WRITE(*,'(L7)')boolen

PRINT*,'Impression d''entier'
i = 1
j = 100
k = 999
WRITE(*,'(I1)')i
WRITE(*,'(I1)')j
WRITE(*,'(I3)')j,k

PRINT*,'Impression de reels'
x = 0.D0
y = 1.2345D0
z = 12345.6789D0

WRITE(*,'(E4.1)')x
WRITE(*,'(E7.1)')x
WRITE(*,'(D15.8)')y
WRITE(*,'(G12.6)')z
WRITE(*,'(F12.6)')z
PRINT*,'Impression de texte (caracteres)'
nom = 'ENSGTI'
WRITE(*,'(A2)')nom
WRITE(*,'(A6)')nom

STOP
END PROGRAM SpecificationFormat




