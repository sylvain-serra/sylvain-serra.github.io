!----------------------------------------------
!        Exemples de programme Fortran
!      pour déterminer le nombre de lignes
!      dans un fichier contenant des données
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 14 Aout 2018
!----------------------------------------------

PROGRAM LectureNombreLigne
IMPLICIT NONE
! Déclaration des variables
!=================================
INTEGER, PARAMETER :: FICH = 10
INTEGER :: NVAL, i
INTEGER :: err
real, dimension(:,:), allocatable  :: Tab
CHARACTER(LEN=50) :: nomFichier


! Coeur du programme
!=================================

! 1) Ouverture du fichier (et contrôle correspondant)
nomFichier = "fichierAvecNombreLignesInconnu.txt"

OPEN(UNIT=FICH, FILE=TRIM(nomFichier), STATUS="OLD", ACTION="READ", IOSTAT=err)

IF(err /= 0) THEN
    PRINT*
    PRINT*,"            PROGRAM ERROR: impossible to open of file: ",TRIM(nomFichier)
    PRINT*,"                           error = ",err
    PRINT*,"                           end of the execution !"
    STOP
ENDIF


! 2) Comptage des lignes
NVAL = 0
DO
	READ(FICH,*,IOSTAT=err)
	IF(IS_IOSTAT_END(err)) EXIT
	NVAL = NVAL + 1
ENDDO

rewind(Fich)

allocate (Tab(Nval,3))

DO i =1 , NVAL
	read(Fich,*) Tab(i,:)
	print*, Tab(i,:)
enddo



CLOSE(FICH)

! 3) Retour utilisateur
PRINT*,"Number of lines in file '",TRIM(nomFichier),"' is equal to: ",NVAL

END PROGRAM LectureNombreLigne
