!----------------------------------------------
!        Exemples de programme Fortran
!      pour la manipulation d'un fichier
!
! Auteur : S. Serra
! Mail   : sylvain.serra@univ-pau.fr
! Date   : 19 Aout 2013
!----------------------------------------------

PROGRAM PratiquesDeBonneConduite
IMPLICIT NONE
! Déclaration des variables
!=================================
INTEGER, PARAMETER :: FICH = 10
INTEGER :: n
INTEGER :: err
CHARACTER(LEN=50) :: nomFichier


! Coeur du programme
!=================================

! 1) Démonstration d'exemples de nommage du fichier
OPEN(UNIT=FICH, FILE="fichierCreeParLeProgramme.txt", STATUS='UNKNOWN')
WRITE(FICH,*)2013
CLOSE(FICH)

nomFichier = "fichierCreeParLeProgramme.txt"
OPEN(UNIT=FICH, FILE=nomFichier, STATUS='UNKNOWN')
READ(FICH,*)n
CLOSE(FICH)
PRINT*,"valeur lue :",n

! 2) Démonstration des utilisations des garde-fous
! Si l'on décommente les lignes suivantes, une erreur devrait se produire à l'exécution
! car on demande une action non faisable

!OPEN(UNIT=FICH, FILE=nomFichier, STATUS='NEW')		! action impossible (fichier existant)

!nomFichier = "FichierNonExistant.txt"
!OPEN(UNIT=FICH, FILE=nomFichier, STATUS='OLD')		! action impossible (fichier non-existant)

! Maintenant nous allons voir un exemple correct, à TOUJOURS imiter lorsque vous gérez des flots
nomFichier = "fichierCreeParLeProgramme.txt"
OPEN(UNIT=FICH, FILE=nomFichier, STATUS='OLD',ACTION="WRITE")
!READ(FICH,*)n
write(FICH,*) 'toto'
CLOSE(FICH)


END PROGRAM PratiquesDeBonneConduite
