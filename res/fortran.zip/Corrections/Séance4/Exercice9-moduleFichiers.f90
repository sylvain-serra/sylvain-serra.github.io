! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 30 Aout 2018
! ----------------------------------------------------------------------------
!   But: gestion des fichiers
! ============================================================================
! ============================================================================


MODULE ManipulationFichiers
IMPLICIT NONE

! 1) Variables 
INTEGER, PARAMETER :: FICH = 10
INTEGER, PARAMETER :: LENGTHFILENAMES = 250, LENGTHEXTENSION = 4
CHARACTER(LEN=LENGTHFILENAMES), PARAMETER :: inputFile = "input.txt"

CHARACTER(LEN=LENGTHFILENAMES) :: outputFile

! 2) Sous-programmes


CONTAINS


FUNCTION filenameWithoutExtension(filename)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	CHARACTER(LEN=LENGTHFILENAMES), INTENT(IN) :: filename
	! 2) Type renvoyé par la fonction
	CHARACTER(LEN=LENGTHFILENAMES) :: filenameWithoutExtension
	! 3) Variables locales
	CHARACTER(LEN=LENGTHFILENAMES) :: buffer
	INTEGER :: length
	
	! 4) Go !
	length = LEN_TRIM(filename)
	filenameWithoutExtension = filename(1:length-LENGTHEXTENSION)
END FUNCTION filenameWithoutExtension


FUNCTION checkConsistency(Ntocheck,Ndata,filename)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	INTEGER, INTENT(IN) :: Ntocheck,Ndata
	CHARACTER(LEN=LENGTHFILENAMES), INTENT(IN) :: filename
	! 2) Type renvoyé par la fonction
	LOGICAL :: checkConsistency
	
	IF(Ntocheck /= Ndata) THEN
		checkConsistency = .FALSE.
	ELSE
		checkConsistency = .TRUE.
	ENDIF
END FUNCTION checkConsistency


END MODULE ManipulationFichiers





