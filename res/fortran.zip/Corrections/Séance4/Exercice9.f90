! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 30 Aout 2018
! ----------------------------------------------------------------------------
!   But: manipulation des fichiers
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM LesFichiers
! 1) Import des modules
! ============================================================================
USE EcrireSurEcran
USE ManipulationFichiers

! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE
INTEGER :: erreur
INTEGER :: i, j, N

INTEGER :: numberOfFilesToTreat
CHARACTER(LEN=LENGTHFILENAMES), DIMENSION(:), ALLOCATABLE :: filesToTreat
LOGICAL :: calculMoyenneOk

INTEGER :: numberOfDataToRead
DOUBLE PRECISION, DIMENSION(:,:), ALLOCATABLE :: dataToRead
DOUBLE PRECISION, DIMENSION(:), ALLOCATABLE :: moyennes
DOUBLE PRECISION :: calculMoyenne

! 3) Initialisation
! ============================================================================
! 3.a/ Début des hostilités
CALL bonjour()

! 3.b/ Ouverture du fichier d'entrée principale
PRINT*,"Reading initial inputfile"
OPEN(UNIT=FICH, FILE=TRIM(inputFile), STATUS="OLD", ACTION="READ")
! => lecture du nombre de fichiers à traiter
READ(FICH,*)numberOfFilesToTreat
IF(numberOfFilesToTreat <= 1) THEN
	PRINT*,"  ERROR: the number of files to treat must be greater than 1"
	PRINT*,"  => program is going to be stopped"
	STOP
ENDIF
! => lecture du nom des fichiers concernés
ALLOCATE(filesToTreat(numberOfFilesToTreat), stat = erreur)
IF(erreur /= 0) THEN
	PRINT*,"  ERROR: memory allocation undergoes an issue"
	PRINT*,"  => program is going to be stopped"
	STOP
ENDIF
DO i = 1,numberOfFilesToTreat
	READ(FICH,*)filesToTreat(i)
ENDDO
! => lecture de la condition de calcul des moyennes
READ(FICH,*)calculMoyenneOk
READ(FICH,*)outputFile
CLOSE(FICH)

! 3.c/ Ouverture et lecture des données contenues dans chaque fichier
PRINT*,"Initalizing the data"
! => on commence par le premier qui sert de base de dimensionnement
OPEN(UNIT=FICH, FILE=TRIM(filesToTreat(1)), STATUS="OLD", ACTION="READ")
READ(FICH,*)numberOfDataToRead
CLOSE(FICH)

ALLOCATE(dataToRead(numberOfFilesToTreat,numberOfDataToRead), stat = erreur)
IF(erreur /= 0) THEN
	PRINT*,"  ERROR: memory allocation undergoes an issue"
	PRINT*,"  => program is going to be stopped"
	STOP
ENDIF

! => on fait la lecture de toutes les données
PRINT*,"Reading all the data in the corresponding files"
DO i = 1,numberOfFilesToTreat
	PRINT*,"  => treatment of file: '",TRIM(filesToTreat(i)),"'"
	OPEN(UNIT=FICH, FILE=TRIM(filesToTreat(i)), STATUS="OLD", ACTION="READ")
	! contrôle de correspondance du nombre de données
	READ(FICH,*)N
	IF(.NOT.(checkConsistency(N,numberOfDataToRead,filesToTreat(i)))) THEN
		PRINT*,"  ERROR: inconsistent number of data in file: '",TRIM(filesToTreat(i)),"'"
		PRINT*,"  => program is going to be stopped"
		STOP
	ENDIF
	! lecture des données
	DO j = 1,numberOfDataToRead
		READ(FICH,*)dataToRead(i,j)
	ENDDO
	! Fin
	CLOSE(FICH)
ENDDO


! 4) Traitement
! ============================================================================
PRINT*,"Treatment"

! 4.a/ Concaténation des résultats dans un seul fichier
OPEN(UNIT=FICH, FILE=TRIM(outputFile), STATUS="NEW", ACTION="WRITE")
DO i = 1,numberOfDataToRead
	WRITE(FICH,*)(dataToRead(j,i),j=1,numberOfFilesToTreat)
ENDDO
CLOSE(FICH)

! 4.b/ Calcul de la moyenne (s'il est demandé)
IF(calculMoyenneOk) THEN
	ALLOCATE(moyennes(numberOfFilesToTreat), stat = erreur)
	IF(erreur /= 0) THEN
		PRINT*,"  ERROR: memory allocation undergoes an issue"
		PRINT*,"  => program is going to be stopped"
		STOP
	ENDIF
	
	moyennes(:) = 0.D0
	DO i = 1,numberOfFilesToTreat
		moyennes(i) = calculMoyenne(dataToRead(i,:),numberOfDataToRead)	
	ENDDO
	
	OPEN(UNIT=FICH, FILE=TRIM(filenameWithoutExtension(outputFile))//"Moyenne.txt", STATUS="NEW", ACTION="WRITE")
		WRITE(FICH,*)(moyennes(i),i=1,numberOfFilesToTreat)
	CLOSE(FICH)
	
	DEALLOCATE(moyennes)
ENDIF


! 5) Fin
! ============================================================================
DEALLOCATE(dataToRead)
DEALLOCATE(filesToTreat)

CALL aurevoir()

STOP

END PROGRAM LesFichiers



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================



FUNCTION calculMoyenne(tableau, N)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	INTEGER, INTENT(IN) :: N
	DOUBLE PRECISION, INTENT(IN) :: tableau(N)
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: calculMoyenne
	! 3) Variables locales
	INTEGER :: i
	DOUBLE PRECISION :: buffer
	
	! 4) Calcul
	buffer = 0.D0
	DO i = 1,N
		buffer = buffer + tableau(i)
	ENDDO
	buffer = buffer / N
	
	calculMoyenne = buffer
END FUNCTION calculMoyenne






