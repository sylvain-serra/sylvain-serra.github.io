! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: manipulation des tableaux
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM LesTableaux
! 1) Import des modules
! ============================================================================
USE UnitesEnseignement
USE EcrireSurEcran

! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE
LOGICAL :: modify, allModify
INTEGER :: index, Neleves, erreur
INTEGER :: i,j
DOUBLE PRECISION, DIMENSION(:,:), ALLOCATABLE :: notesEleves
DOUBLE PRECISION, DIMENSION(:), ALLOCATABLE :: moyenneEleves
DOUBLE PRECISION, DIMENSION(nombreMatieres) :: moyenneMatieres

! 3) Initialisation
! ============================================================================
! 3.a/ Début des hostilités
CALL bonjour()

! 3.b/ Initialisation par défaut des coefficients de chaque matières
CALL initTableauCoefs(coefficientsMatiere)

PRINT*,"Do you want to modify one or all coefficients ? (T or F)"
READ(*,*)modify
IF(modify) THEN
	PRINT*,"Do you want to modify all the coefficients ? (T or F)"
	READ(*,*)allModify
	IF(allModify) THEN
		CALL modifTableau(coefficientsMatiere, nombreMatieres)
	ELSE
		PRINT*,"  So, which value do you want to change:"
		READ(*,*)index
		DO WHILE((index < 1) .OR. (index > nombreMatieres))
			PRINT*,"  uhuh... This value is not in the acceptable interval, give another value please:"
			READ(*,*)index
		ENDDO
		CALL modifElementTableau(coefficientsMatiere, nombreMatieres, index)
	ENDIF
ENDIF
PRINT*

! 4) Calcul des moyennes des élèves
! ============================================================================
! 4.a/ Saisie nombre d'élèves
PRINT*,"How many students ?"
READ(*,*)Neleves

CALL check(Neleves)

! 4.b/ Allocation mémoire
ALLOCATE(notesEleves(Neleves,nombreMatieres), stat = erreur)
IF(erreur /= 0) THEN
	PRINT*,"  ERROR: memory allocation undergoes an issue"
	PRINT*,"  => program is going to be stopped"
	STOP
ENDIF

ALLOCATE(moyenneEleves(Neleves), stat = erreur)
IF(erreur /= 0) THEN
	PRINT*,"  ERROR: memory allocation undergoes an issue"
	PRINT*,"  => program is going to be stopped"
	STOP
ENDIF

! 4.d/ Saisie des notes
PRINT*,"Marks of the students..."
DO i = 1,Neleves
	PRINT*,"  Student ",i
	DO j = 1,nombreMatieres
		PRINT*,"  => Value ",j,":"
		READ(*,*)notesEleves(i,j)
		DO WHILE ((notesEleves(i,j)<noteMin) .OR. (notesEleves(i,j)>noteMax))
			PRINT*,"  it should be between ",noteMin," and",noteMax
			PRINT*,"  try again"
			READ(*,*)notesEleves(i,j)
		ENDDO
	ENDDO
ENDDO

! 4.d/ Calcul des moyennes
moyenneEleves(:) = 0.D0
DO i = 1,Neleves
	DO j = 1,nombreMatieres
		moyenneEleves(i) = moyenneEleves(i) + notesEleves(i,j) * coefficientsMatiere(j)
	ENDDO
	moyenneEleves(i) = moyenneEleves(i) / SUM(coefficientsMatiere)
ENDDO

moyenneMatieres(:) = 0.D0
DO i = 1,nombreMatieres
	DO j = 1,Neleves
		moyenneMatieres(i) = moyenneMatieres(i) + notesEleves(j,i)
	ENDDO
ENDDO
moyenneMatieres(:) = moyenneMatieres(:)/Neleves

! 5) Affichage
! ============================================================================
PRINT*,""
PRINT*,"Final results..."

PRINT*,"For the students:"
CALL resultat(moyenneEleves, Neleves)

PRINT*,"For each courses:"
CALL resultat(moyenneMatieres, nombreMatieres)


! 6) Fin
! ============================================================================
DEALLOCATE(moyenneEleves)
DEALLOCATE(notesEleves)

CALL aurevoir()

STOP

END PROGRAM LesTableaux



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================



! Sous-programmes de contrôle
! -------------------------------------------------
SUBROUTINE check(N)
	! Import des modules
	USE UnitesEnseignement
	! 2) Type et rôle des arguments 
	IMPLICIT NONE
	INTEGER, INTENT(INOUT) :: N
	! 3) Variables locales
	LOGICAL :: onContinue 
	
	! 4) Contrôles
	! 4.a/ valeur comprise dans les bornes acceptables
	onContinue = (N < 1) .OR. (N>nombreElevesMax)
	
	! 4.b/ corrections
	DO WHILE(onContinue)
		PRINT*,"The value is not in the possible range. Please change it:"
		READ(*,*)N
		onContinue = (N < 1) .OR. (N>nombreElevesMax)
	ENDDO
END SUBROUTINE check



! Procédures de modification de tableau
! -------------------------------------------------

SUBROUTINE modifTableau(tableau, N)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: N
	INTEGER, DIMENSION(N), INTENT(OUT) :: tableau
	! 2) Variables locales
	INTEGER :: i
	
	! 3) Modifications
	PRINT*,"Method to modify ALL the elements of an array"
	PRINT*,"Number of elements to define:",N
	DO i = 1,N
		PRINT*,"  Enter the value for index ",i
		READ(*,*)tableau(i)
	ENDDO
END SUBROUTINE modifTableau


SUBROUTINE modifElementTableau(tableau, N, i)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: N,i
	INTEGER, DIMENSION(N), INTENT(OUT) :: tableau
	
	! 2) Modification
	PRINT*,"Method to modify ONE element of an array: Give its value"
	READ(*,*)tableau(i)
END SUBROUTINE modifElementTableau







