! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 29 Aout 2018
! ----------------------------------------------------------------------------
!   But: gestion de l'affichage écrant
! ============================================================================
! ============================================================================


MODULE EcrireSurEcran
IMPLICIT NONE

! 1) Variables 
!... aucune

! 2) Sous-programmes

CONTAINS

! Affichage classique (i.e. texte seul)
! -------------------------------------------------
SUBROUTINE bonjour()
	IMPLICIT NONE	
	PRINT*
	PRINT*,"============================================="
	PRINT*,"Hello"
END SUBROUTINE bonjour


SUBROUTINE aurevoir()
	IMPLICIT NONE	
	PRINT*,"End"
	PRINT*,"That's all folks !"
	PRINT*,"============================================="
	PRINT*
END SUBROUTINE aurevoir



! Affichage plus élaboré
! -------------------------------------------------
SUBROUTINE resultat(tableau, N)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: N
	DOUBLE PRECISION, DIMENSION(N), INTENT(IN) :: tableau
	! 2) Variables locales
	INTEGER :: i
	
	! 3) Affichage
	PRINT*,"  => ",(tableau(i),i=1,N)
END SUBROUTINE resultat



END MODULE EcrireSurEcran





