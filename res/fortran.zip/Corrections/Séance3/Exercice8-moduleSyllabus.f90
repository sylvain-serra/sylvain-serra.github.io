! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 29 Aout 2018
! ----------------------------------------------------------------------------
!   But: définition des matières et de leurs coefficients (stockés dans un tableau)
! ============================================================================
! ============================================================================


MODULE UnitesEnseignement
IMPLICIT NONE

! 1) Variables 
INTEGER, PARAMETER :: nombreMatieres = 4
INTEGER, PARAMETER :: CoefParDefaut1 = 1, CoefParDefaut2 = 3, CoefParDefaut3 = 1, CoefParDefaut4 = 2
INTEGER, DIMENSION(nombreMatieres) :: coefficientsMatiere

INTEGER, PARAMETER :: nombreElevesMin = 1
INTEGER, PARAMETER :: nombreElevesMax = 99

INTEGER, PARAMETER :: noteMin = 0.0
INTEGER, PARAMETER :: noteMax = 20.0			! à adapter en 10 ou 100 selon le pays

! 2) Sous-programmes

CONTAINS


! Procédures d'initialisation
! -------------------------------------------------

SUBROUTINE initTableauCoefs(tableau)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, DIMENSION(nombreMatieres), INTENT(OUT) :: tableau
	
	! 2) Initialisation
	tableau(1) = CoefParDefaut1
	tableau(2) = CoefParDefaut2
	tableau(3) = CoefParDefaut3
	tableau(4) = CoefParDefaut4
END SUBROUTINE initTableauCoefs


END MODULE UnitesEnseignement





