! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: rentrer deux nombres réels et en effectuer les opérations
!   élémentaires avant de les afficher
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM MonPremierProgrammeBoost

! 1) Import des modules utiles
! ============================================================================
USE communicationTools


! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE
DOUBLE PRECISION :: N1, N2, N3, N4											! les nombres saisis par l'utilisateur
DOUBLE PRECISION :: addition, soustraction, multiplication, division		! les opérations


! 3) Coeur du programme
! ============================================================================

! 3.a/ Affichage de la demande de saisie
CALL whatToDo()

! 3.b/ Lecture et sauvegarde des nombres saisis
READ(*,*)N1
READ(*,*)N2
READ(*,*)N3
READ(*,*)N4

! 3.c/ Réalisation des opérations élémentaires et affichage simultané
! 3.c.i: cas N1-N2
CALL calcul(N1, N2, addition, soustraction, multiplication, division)
CALL final(N1, N2, addition, soustraction, multiplication, division)
! 3.c.ii: cas N1-N3
CALL calcul(N1, N3, addition, soustraction, multiplication, division)
CALL final(N1, N3, addition, soustraction, multiplication, division)
! 3.c.iii: cas N1-N4
CALL calcul(N1, N4, addition, soustraction, multiplication, division)
CALL final(N1, N4, addition, soustraction, multiplication, division)
! 3.c.iv: cas N2-N3
CALL calcul(N2, N3, addition, soustraction, multiplication, division)
CALL final(N2, N3, addition, soustraction, multiplication, division)
! 3.c.v: cas N2-N4
CALL calcul(N2, N4, addition, soustraction, multiplication, division)
CALL final(N2, N4, addition, soustraction, multiplication, division)
! 3.c.vi: cas N3-N4
CALL calcul(N3, N4, addition, soustraction, multiplication, division)
CALL final(N3, N4, addition, soustraction, multiplication, division)

! 3.d/ Fin du programme
PRINT*
PRINT*,"Fin !"



STOP

END PROGRAM MonPremierProgrammeBoost



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

! Procédures de calcul
! -------------------------------------------------

!  => Opérations élementaires
SUBROUTINE calcul(nb1, nb2, op1, op2, op3, op4)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: nb1, nb2					! Les deux nombres initiaux
	DOUBLE PRECISION, INTENT(OUT) :: op1, op2, op3, op4			! Les résultats des opérations élémentaires
	! 2) Variables internes
	DOUBLE PRECISION, EXTERNAL :: fonctionAddition
	
	! 3) coeur de la subroutine: réalisation des opérations élémentaires
	op4 = nb1 / nb2												! nb: on retrouve le précédent problème
	op3 = nb1 * nb2
	op2 = nb1 - nb2
	op1 = fonctionAddition(nb1, nb2)
END SUBROUTINE calcul


FUNCTION fonctionAddition(a,b)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: a,b
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: fonctionAddition
	
	! 3) Calcul
	fonctionAddition = a + b
END FUNCTION fonctionAddition

