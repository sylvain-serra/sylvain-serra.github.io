! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: rentrer deux nombres réels et en effectuer les opérations
!   élémentaires avant de les afficher
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM MonPremierProgrammeBoost

! 1) Import des modules utiles
! ============================================================================
USE communicationTools


! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE
DOUBLE PRECISION :: nombre1, nombre2										! les nombres saisis par l'utilisateur
DOUBLE PRECISION :: addition, soustraction, multiplication, division		! les opérations
DOUBLE PRECISION :: minimum, maximum
DOUBLE PRECISION :: trouverMinimum, trouverMaximum							! variables servant à stocker la valeur des fonctions correspondantes


! 3) Coeur du programme
! ============================================================================

! 3.a/ Affichage de la demande de saisie
CALL whatToDo()

! 3.b/ Lecture et sauvegarde des nombres saisis
READ(*,*)nombre1
READ(*,*)nombre2

! 3.c/ Réalisation des opérations élémentaires
CALL calcul(nombre1, nombre2, addition, soustraction, multiplication, division)

! 3.d/ Affichage des résultats
CALL final(addition, soustraction, multiplication, division)

minimum = trouverMinimum(addition, soustraction)
minimum = trouverMinimum(minimum, multiplication)
minimum = trouverMinimum(minimum, division)
maximum = trouverMaximum(addition, soustraction)
maximum = trouverMaximum(maximum, multiplication)
maximum = trouverMaximum(maximum, division)
PRINT*,"Les extremums valent:",minimum," et ",maximum

! 3.e/ Fin du programme
PRINT*
PRINT*,"Fin !"


STOP

END PROGRAM MonPremierProgrammeBoost



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

! Procédures de calcul
! -------------------------------------------------

!  => Opérations élementaires
SUBROUTINE calcul(nb1, nb2, op1, op2, op3, op4)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: nb1, nb2					! Les deux nombres initiaux
	DOUBLE PRECISION, INTENT(OUT) :: op1, op2, op3, op4			! Les résultats des opérations élémentaires
	
	! 2) coeur de la subroutine: réalisation des opérations élémentaires
	op4 = nb1 / nb2												! nb: on retrouve le précédent problème
	op3 = nb1 * nb2
	op2 = nb1 - nb2
	op1 = nb1 + nb2
END SUBROUTINE calcul


! Fonctions utiles
! -------------------------------------------------

FUNCTION trouverMinimum(a,b)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: a,b
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: trouverMinimum
	
	! 3) Calcul
	trouverMinimum = MIN(a,b)									! nb: cette fonction existe uniquement par souci pédagogique, n'est-ce-pas.
END FUNCTION trouverMinimum

FUNCTION trouverMaximum(a,b)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: a,b
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: trouverMaximum
	
	! 3) Calcul
	trouverMaximum = MAX(a,b)									! nb: idem
END FUNCTION trouverMaximum

