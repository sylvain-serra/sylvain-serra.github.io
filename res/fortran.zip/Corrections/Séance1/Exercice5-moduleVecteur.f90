! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: définition d'un module contenant la définition d'un 
!   nouveau type pour pouvoir déclarer des vecteurs et aussi
!   effectuer des opérations 
! ============================================================================
! ============================================================================


MODULE vectors
IMPLICIT NONE

! 1) Types
TYPE VECTEUR
	DOUBLE PRECISION :: x, y, z
END TYPE

! 2) Variables (ici aucune...)


! 3) Sous-programmes

CONTAINS


! Procédures de calcul
! -------------------------------------------------

SUBROUTINE produitScalaire(V1, V2, produit)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	TYPE(VECTEUR), INTENT(IN) :: V1, V2					! Les deux vecteurs
	DOUBLE PRECISION, INTENT(OUT) :: produit			! Leur produit scalaire
	
	! 2) Calcul
	produit = V1%x*V2%x + V1%y*V2%y + V1%z*V2%z
END SUBROUTINE produitScalaire


SUBROUTINE produitVectoriel(V1, V2, produit)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	TYPE(VECTEUR), INTENT(IN) :: V1, V2					! Les deux vecteurs
	TYPE(VECTEUR), INTENT(OUT) :: produit				! Leur produit vectoriel (nb: vous noterez que ce n'est plus un nombre réel !)
	! 2) Variables internes
	DOUBLE PRECISION :: coordX, coordY, coordZ
	
	! 3) Calcul
	! 3.a/ calcul de chaque composante
produit%x = V1%y*V2%z - V2%y*V1%z
	coordY = V1%z*V2%x - V2%z*V1%x
	coordZ = V1%x*V2%y - V2%x*V1%y
	
	! 3.b/ affectation de la valeur des composantes
!	 = coordX
	produit%y = coordY
	produit%z = coordZ
END SUBROUTINE produitVectoriel


FUNCTION normale(V1, V2)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	TYPE(VECTEUR), INTENT(IN) :: V1, V2
	! 2) Type renvoyé par la fonction
	TYPE(VECTEUR) :: normale
	! 3) Variables internes
	TYPE(VECTEUR) :: prodVec
	DOUBLE PRECISION :: magVec
	
	! 4) Calcul
	! 4.a/ produit vectoriel
	CALL produitVectoriel(V1, V2, prodVec)
	
	! 4.b/ division par la magnitude
	CALL produitScalaire(prodVec, prodVec, magVec)
	magVec = DSQRT(magVec)
	
	! 4.c/ Final
	normale%x = prodVec%x / magVec
	normale%y = prodVec%y / magVec
	normale%z = prodVec%z / magVec
END FUNCTION normale


END MODULE vectors





