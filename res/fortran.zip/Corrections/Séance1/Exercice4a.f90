! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: rentrer deux nombres réels et en effectuer les opérations
!   élémentaires avant de les afficher
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM MonPremierProgrammeBoost

! 1) Déclaration des variables
! ============================================================================
IMPLICIT NONE
DOUBLE PRECISION :: nombre1, nombre2										! les nombres saisis par l'utilisateur
DOUBLE PRECISION :: addition, soustraction, multiplication, division		! les opérations
DOUBLE PRECISION :: minimum, maximum
DOUBLE PRECISION :: trouverMinimum, trouverMaximum				! variables servant à stocker la valeur des fonctions correspondantes

! 2) Coeur du programme
! ============================================================================

! 2.a/ Affichage de la demande de saisie
CALL whatToDo()

! 2.b/ Lecture et sauvegarde des nombres saisis
READ(*,*)nombre1
READ(*,*)nombre2

! 2.c/ Réalisation des opérations élémentaires
CALL calcul(nombre1, nombre2, addition, soustraction, multiplication, division)

! 2.d/ Affichage des résultats
CALL final(addition, soustraction, multiplication, division)

minimum = trouverMinimum(addition, soustraction)
minimum = trouverMinimum(minimum, multiplication)
minimum = trouverMinimum(minimum, division)
maximum = trouverMaximum(addition, soustraction)
maximum = trouverMaximum(maximum, multiplication)
maximum = trouverMaximum(maximum, division)
PRINT*,"Les extremums valent:",minimum," et ",maximum

! 2.e/ Fin du programme
PRINT*
PRINT*,"Fin !"


STOP

END PROGRAM MonPremierProgrammeBoost



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

! Procédures d'affichage
! -------------------------------------------------

! => Introduction
SUBROUTINE whatToDo()									! Procédure sans arguments
	IMPLICIT NONE
	
	PRINT*,"Bonjour"
	PRINT*,"Pouvez-vous saisir deux nombres svp :"
END SUBROUTINE whatToDo


! => Présentation finale des résultats
SUBROUTINE final(add, sous, mult, div)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: add, sous, mult, div		! Les chiffres à afficher (qui sont les résultats précédemment calculés)
	
	! 2) Affichage de chaque résultat
	PRINT*,"Leur addition vaut:",add
	PRINT*,"Leur soustraction vaut:",sous
	PRINT*,"Leur multiplication vaut:",mult
	PRINT*,"Leur division vaut:",div
END SUBROUTINE final


! Procédures de calcul
! -------------------------------------------------

!  => Opérations élementaires
SUBROUTINE calcul(nb1, nb2, op1, op2, op3, op4)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: nb1, nb2					! Les deux nombres initiaux
	DOUBLE PRECISION, INTENT(OUT) :: op1, op2, op3, op4			! Les résultats des opérations élémentaires
	
	! 2) coeur de la subroutine: réalisation des opérations élémentaires
	op4 = nb1 / nb2												! nb: on retrouve le précédent problème
	op3 = nb1 * nb2
	op2 = nb1 - nb2
	op1 = nb1 + nb2
END SUBROUTINE calcul


! Fonctions utiles
! -------------------------------------------------

FUNCTION trouverMinimum(a,b)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: a,b
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: trouverMinimum
	
	! 3) Calcul
	trouverMinimum = MIN(a,b)									! nb: cette fonction existe uniquement par souci pédagogique, n'est-ce-pas.
END FUNCTION trouverMinimum

FUNCTION trouverMaximum(a,b)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: a,b
	! 2) Type renvoyé par la fonction
	DOUBLE PRECISION :: trouverMaximum
	
	! 3) Calcul
	trouverMaximum = MAX(a,b)									! nb: idem
END FUNCTION trouverMaximum