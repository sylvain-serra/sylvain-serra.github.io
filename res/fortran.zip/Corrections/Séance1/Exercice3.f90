! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: rentrer deux nombres réels et en effectuer les opérations
!   élémentaires avant de les afficher
! ============================================================================
! ============================================================================


PROGRAM MonPremierProgramme

! 1) Déclaration des variables
! ============================================================================
IMPLICIT NONE
DOUBLE PRECISION :: nombre1, nombre2										! les nombres saisis par l'utilisateur
DOUBLE PRECISION :: addition, soustraction, multiplication, division		! les opérations


! 2) Coeur du programme
! ============================================================================

! 2.a/ Affichage de la demande de saisie
PRINT*,"Bonjour"
PRINT*,"Pouvez-vous saisir deux nombres svp :"

! 2.b/ Lecture et sauvegarde des nombres saisis
READ(*,*)nombre1
READ(*,*)nombre2

! 2.c/ Réalisation des opérations élémentaires
addition       = nombre1 + nombre2
soustraction   = nombre1 - nombre2
multiplication = nombre1 * nombre2
division       = nombre1 / nombre2											! nb: vous noterez au passage le risque si le second chiffre est nul... Nous apprendrons comment proposer un "patch" 

! 2.d/ Affichage des résultats
PRINT*,"Leur addition vaut:",addition
PRINT*,"Leur soustraction vaut:",soustraction
PRINT*,"Leur multiplication vaut:",multiplication
PRINT*,"Leur division vaut:",division

! 2.e/ Fin du programme
PRINT*
PRINT*,"Fin !"

STOP

END PROGRAM MonPremierProgramme



