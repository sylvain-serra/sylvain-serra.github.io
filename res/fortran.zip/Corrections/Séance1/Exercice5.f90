! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: opérations vectorielles... et manipulation d'un type "structure"
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM MonSecondProgramme

! 1) Import des modules utiles
! ============================================================================
USE vectors


! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE

INTEGER, PARAMETER :: nombreDeVecteursSaisis = 4
TYPE(VECTEUR) :: vecA, vecB, vecC, vecD

DOUBLE PRECISION :: coord1, coord2, coord3
DOUBLE PRECISION :: scalProd

TYPE(VECTEUR) :: vecProd
TYPE(VECTEUR) :: normaleVecteur

! 3) Coeur du programme
! ============================================================================

! 3.a/ Saisie des coordonnées de chaque vecteur
! 3.a.i: vecteur A
PRINT*,"Entrez les trois composantes du vecteur A:"				! 1ère méthode (un peu lourde)
READ(*,*)vecA

! 3.a.ii: vecteur B
PRINT*,"Entrez les trois composantes du vecteur B:"
READ(*,*)coord1
READ(*,*)coord2
READ(*,*)coord3
vecB%x = coord1
vecB%y = coord2
vecB%z = coord3
! 3.a.iii: vecteur C
PRINT*,"Entrez les trois composantes du vecteur C:"				! 2ème méthode (plus rapide et moins coûteuse - en stockage et en temps CPU-)
READ(*,*)vecC%x
READ(*,*)vecC%y
READ(*,*)vecC%z
! 3.a.iv: vecteur D
PRINT*,"Entrez les trois composantes du vecteur D:"
READ(*,*)vecD%x
READ(*,*)vecD%y
READ(*,*)vecD%z

! 3.b/ Calcul du produit scalaire et vectoriel de A et B
CALL produitScalaire(vecA, vecB, scalProd)
CALL produitVectoriel(vecA, vecB, vecProd)

CALL affiche(scalProd, vecProd)

! 3.c/ Calcul de la normale de A et B
normaleVecteur = normale(vecA, vecB)

PRINT*,"Affichage de la normale:"
CALL afficheVecteur(normaleVecteur)

! 3.d/ Fin du programme
PRINT*
PRINT*,"Fin !"


STOP

END PROGRAM MonSecondProgramme



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

SUBROUTINE affiche(nb, vec)
	! 1) Import module
	USE vectors
	! 2) Type et rôle des arguments
	IMPLICIT NONE
	DOUBLE PRECISION, INTENT(IN) :: nb
	TYPE(VECTEUR), INTENT(IN) :: vec
	
	! 3) Affichage
	PRINT*,"Le produit scalaire vaut: ",nb
	PRINT*,"Le produit vectoriel vaut: (",vec%x,vec%y,vec%z,")"
END SUBROUTINE affiche


SUBROUTINE afficheVecteur(vec)
	! 1) Import module
	USE vectors
	! 2) Type et rôle des arguments
	IMPLICIT NONE
	TYPE(VECTEUR), INTENT(IN) :: vec
	
	! 3) Affichage
	PRINT*,"Composantes du vecteur:"
	PRINT*,"  x : ",vec%x
	PRINT*,"  y : ",vec%y
	PRINT*,"  z : ",vec%z
END SUBROUTINE afficheVecteur

