! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: définition d'un module partageant des variables et des sous-programmes
! ============================================================================
! ============================================================================


MODULE communicationTools
IMPLICIT NONE
! 1) Variables
INTEGER, PARAMETER :: nombreDeChiffresSaisis = 4		! paramètre constant indiquant combien de nombres devra rentrer l'utilisateur

! 2) Sous-programmes

CONTAINS



! Introduction
! -------------------------------------------------
SUBROUTINE whatToDo()									! Procédure sans arguments
	IMPLICIT NONE
	
	PRINT*,"Bonjour"
	PRINT*,"Pouvez-vous saisir",nombreDeChiffresSaisis," nombres svp :"
END SUBROUTINE whatToDo



! Présentation finale des résultats
! -------------------------------------------------
SUBROUTINE final(N1, N2, add, sous, mult, div)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	DOUBLE PRECISION, INTENT(IN) :: N1, N2						! Les chiffres étudiés
	DOUBLE PRECISION, INTENT(IN) :: add, sous, mult, div		! Les chiffres à afficher (qui sont les résultats précédemment calculés)
	
	! 2) Affichage de chaque résultat
	PRINT*,"Calculs pour ",N1," et ",N2
	PRINT*,"  Leur addition vaut:",add
	PRINT*,"  Leur soustraction vaut:",sous
	PRINT*,"  Leur multiplication vaut:",mult
	PRINT*,"  Leur division vaut:",div
	PRINT*
END SUBROUTINE final




END MODULE communicationTools





