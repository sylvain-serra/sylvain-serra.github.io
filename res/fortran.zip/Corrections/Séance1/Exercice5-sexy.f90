! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!  Serra
! ----------------------------------------------------------------------------
!   But: opérations vectorielles... et manipulation d'un type "structure"
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM MonSecondProgramme

! 1) Import des modules utiles
! ============================================================================
USE vectors


! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE

INTEGER, PARAMETER :: nombreDeVecteursSaisis = 4
TYPE(VECTEUR), dimension(4) :: tab
!DOUBLE PRECISION :: coord1, coord2, coord3
DOUBLE PRECISION :: scalProd
TYPE(VECTEUR) :: vecProd
TYPE(VECTEUR) :: normaleVecteur
integer :: i,j
! 3) Coeur du programme
! ============================================================================

! 3.a/ direct, 3 composantes des 4 cases du tableau type vecteur
PRINT*,"Entrez les trois composantes des 4 vecteurs"
READ(*,*)tab

do i=1,4

do j=1, 4
! 3.b/ Calcul du produit scalaire et vectoriel de i et j
CALL produitScalaire(tab(i), tab(j), scalProd)
CALL produitVectoriel(tab(i), tab(j), vecProd)

print*, " le prod scal des vects", i, " et ", j, " est ", scalProd
print*, " le prod vecto des vects", i, " et ", j, " est ", vecprod
! 3.c/ Calcul de la normale de A et B
normaleVecteur = normale(tab(i), tab(j))

PRINT*,"Affichage de leur normale:", normaleVecteur

end do
end do

! 3.d/ Fin du programme
PRINT*
PRINT*,"Fin !"


STOP

END PROGRAM MonSecondProgramme



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

SUBROUTINE affiche(nb, vec)
	! 1) Import module
	USE vectors
	! 2) Type et rôle des arguments
	IMPLICIT NONE
	DOUBLE PRECISION, INTENT(IN) :: nb
	TYPE(VECTEUR), INTENT(IN) :: vec
	
	! 3) Affichage
	PRINT*,"Le produit scalaire vaut: ",nb
	PRINT*,"Le produit vectoriel vaut: (",vec%x,";",vec%y,";",vec%z,")"
END SUBROUTINE affiche


SUBROUTINE afficheVecteur(vec)
	! 1) Import module
	USE vectors
	! 2) Type et rôle des arguments
	IMPLICIT NONE
	TYPE(VECTEUR), INTENT(IN) :: vec
	
	! 3) Affichage
	PRINT*,"Composantes du vecteur:"
	PRINT*,"  x : ",vec%x
	PRINT*,"  y : ",vec%y
	PRINT*,"  z : ",vec%z
END SUBROUTINE afficheVecteur

