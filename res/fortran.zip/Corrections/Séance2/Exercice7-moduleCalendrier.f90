! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: définition d'un module avec les informations du calendrier
! ============================================================================
! ============================================================================


MODULE calendar
IMPLICIT NONE

! 1) Variables 
INTEGER, PARAMETER :: moisMin=1, moisMax=12			! Calendrier julien
INTEGER, PARAMETER :: nbJoursAnnee=365


END MODULE calendar





