! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: utilisation des tests
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM Tests
! 1) Import des modules
! ============================================================================
USE calendar

! 2) Déclaration des variables
! ============================================================================
IMPLICIT NONE
INTEGER :: jour, mois, annee
INTEGER :: nja
INTEGER :: nombreJour								! type renvoyé par la fonction éponyme
INTEGER :: nbJourDebutAnnee, nbJourFinAnnee
INTEGER :: siecle, nbJourDebutSiecle, nbJourFinSiecle

! 3) Initialisation
! ============================================================================
! 3.a/ Début des hostilités
CALL bonjour()

! 3.b/ Lecture de l'année
PRINT*,"What is the year ?"
READ(*,*)annee

! 3.c/ Lecture du mois
PRINT*,"What is the month ?"
DO										! Verification : le numero de mois doit etre entre 1 et 12
	READ(*,*)mois
	IF ( (mois>=moisMin) .AND. (mois<=moisMax) ) EXIT
	PRINT*,"  => error: the month is an integer value between 1 and 12"
	PRINT*,"  Try again please:"
END DO

! 3.d/ Lecture du jour
PRINT*,"What is the day ?"
DO										! Verification : le numero de mois doit etre entre 1 et 12
	READ(*,*)jour
	IF ( jour <= nombreJour(mois) ) EXIT
	PRINT*,"  => error: the day is an integer value between 1 and",nombreJour(mois)
	PRINT*,"  Try again please:"
END DO

! 4) Calculs des jours restants
! ============================================================================
! 4.a/ Calcul du numéro du jour courant
nja = jour + 31*(mois-1)
IF (mois>=3) THEN
	nja = nja - INT(0.4*mois + 2.3) 
ENDIF

! 4.b/ Calcul du nombre de jours entre le début et la fin de l'année
nbJourDebutAnnee = nja
nbJourFinAnnee   = nbJoursAnnee - nbJourDebutAnnee

! 4.c/ Calcul du nombre de jours entre le début et la fin du siècle
siecle = annee / 100

nbJourDebutSiecle = (annee - 100*siecle)*nbJoursAnnee + nbJourDebutAnnee
nbJourFinSiecle   = (100 - (annee - 100*siecle))*nbJoursAnnee + nbJourFinAnnee

! 5) Affichage
! ============================================================================
PRINT*

CALL afficheJourAnnee(nbJourDebutAnnee,nbJourFinAnnee)

CALL afficheJourSiecle(nbJourDebutSiecle,nbJourFinSiecle)

! 6) Fin
! ============================================================================
CALL aurevoir()

STOP

END PROGRAM Tests



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

! Procédures d'affichage
! -------------------------------------------------

! Affichage classique (i.e. texte seul)
SUBROUTINE bonjour()
	IMPLICIT NONE	
	PRINT*
	PRINT*,"============================================="
	PRINT*,"Hello"
END SUBROUTINE bonjour

SUBROUTINE aurevoir()
	IMPLICIT NONE	
	PRINT*,"End"
	PRINT*,"That's all folks !"
	PRINT*,"============================================="
	PRINT*
END SUBROUTINE aurevoir

! Affichage plus élaboré
SUBROUTINE afficheJourAnnee(debut,fin)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: debut,fin
	
	! 2) Affichage
	PRINT*,"For the current year, we have:"
	PRINT*,"   => numbers of days left:",debut
	PRINT*,"   => numbers of days remaining:",fin
END SUBROUTINE 

SUBROUTINE afficheJourSiecle(debut,fin)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: debut,fin
	
	! 2) Affichage
	PRINT*,"For the current century, we have:"
	PRINT*,"   => numbers of days left:",debut
	PRINT*,"   => numbers of days remaining:",fin	
END SUBROUTINE 


! Fonctions de contrôle
! -------------------------------------------------

FUNCTION nombreJour(mois)
	IMPLICIT NONE
	! 1) Type et rôle des arguments 
	INTEGER, INTENT(IN) :: mois
	! 2) Type renvoyé par la fonction
	INTEGER :: nombreJour
	
	! 3) Calcul
	SELECT CASE (mois)												! Nombre de jours fonction du mois
		CASE (1,3,5,7,8,10,12)
			nombreJour = 31
		CASE (4,6,9,11)
			nombreJour = 30
		CASE (2)
			nombreJour = 28											! nb: années bissextiles non prises en compte
		case DEFAULT												! nb: ne devrait jamais arriver !
			WRITE(*,*)"** Oups, something wrong happens **"
			STOP
	END SELECT
END FUNCTION nombreJour







