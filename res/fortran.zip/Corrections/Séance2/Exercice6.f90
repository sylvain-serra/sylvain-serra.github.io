! ============================================================================
! ============================================================================
!   TD PROGRAMMATION FORTRAN - ENSGTI 1A
!   S. Serra
!   mail : sylvain.serra@univ-pau.fr
!   Version du 28 Aout 2018
! ----------------------------------------------------------------------------
!   But: utilisation des boucles
! ============================================================================
! ============================================================================




! ============================================================================
!							PROGRAMME PRINCIPAL
! ============================================================================


PROGRAM Looping

! 1) Déclaration des variables
! ============================================================================
IMPLICIT NONE
INTEGER :: N
DOUBLE PRECISION :: moyenne


! 2) Coeur du programme
! ============================================================================

! 2.a/ Affichage de la demande de saisie
CALL bonjour()

! 2.b/ Lecture et sauvegarde des nombres saisis
READ(*,*)N

! 2.c/ Calcul
moyenne = 0.D0

CALL calculPrixMoyen(N, moyenne)

PRINT*,"La moyenne des prix vaut:",moyenne

! 2.d/ Fin du programme
PRINT*
PRINT*,"Fin !"

STOP

END PROGRAM Looping



! ============================================================================
!								SOUS-PROGRAMMES
! ============================================================================

! Procédures d'affichage
! -------------------------------------------------

SUBROUTINE bonjour()
	IMPLICIT NONE	
	PRINT*,"Bonjour"
	PRINT*,"Pouvez-vous saisir le nombres de prix voulus :"
END SUBROUTINE bonjour


! Procédures de calcul
! -------------------------------------------------
SUBROUTINE calculPrixMoyen(N, moyenne)
	IMPLICIT NONE
	! 1) Type et rôle des arguments
	INTEGER, INTENT(IN) :: N
	DOUBLE PRECISION, INTENT(OUT) :: moyenne
	! 2) Variables internes
	INTEGER :: i
	DOUBLE PRECISION :: prix
	
	! 3) Calcul
	DO i = 1,N
		write(*,'(A, I2)')"Saisie du prix N°",i
		READ(*,*)prix
		moyenne = moyenne + prix
	ENDDO
	moyenne = moyenne / N
END SUBROUTINE calculPrixMoyen
